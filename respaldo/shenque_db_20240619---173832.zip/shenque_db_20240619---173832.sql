-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: shenque_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `antecedentes_medicos`
--

DROP TABLE IF EXISTS `antecedentes_medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antecedentes_medicos` (
  `antecedentes_medicos_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `tipo_antecedente_id` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `estatus_ant` enum('1','2') NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`antecedentes_medicos_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `tipo_antecedente_id` (`tipo_antecedente_id`),
  CONSTRAINT `antecedentes_medicos_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `antecedentes_medicos_ibfk_2` FOREIGN KEY (`tipo_antecedente_id`) REFERENCES `tipo_antecedente` (`tipo_antecedente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antecedentes_medicos`
--

LOCK TABLES `antecedentes_medicos` WRITE;
/*!40000 ALTER TABLE `antecedentes_medicos` DISABLE KEYS */;
/*!40000 ALTER TABLE `antecedentes_medicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria` (
  `auditoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(45) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `modulo` varchar(30) NOT NULL,
  PRIMARY KEY (`auditoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1244 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES (1209,'2024-06-16 21:37:37',32,'actualización','Aura ha actualizado al elemento id 27 los campos estatus_usu en el módulo usuarios','usuarios'),(1210,'2024-06-16 21:37:40',32,'actualización','Aura ha actualizado al elemento id 28 los campos estatus_usu en el módulo usuarios','usuarios'),(1211,'2024-06-16 21:37:42',32,'actualización','Aura ha actualizado al elemento id 29 los campos estatus_usu en el módulo usuarios','usuarios'),(1212,'2024-06-16 21:37:47',32,'actualización','Aura ha actualizado al elemento id 30 los campos estatus_usu en el módulo usuarios','usuarios'),(1213,'2024-06-16 21:38:03',32,'actualización','Aura ha actualizado al elemento id 31 los campos estatus_usu en el módulo usuarios','usuarios'),(1214,'2024-06-16 22:26:30',28,'inserción','Enrique ha insertado un nuevo elemento Alcohol Etílico en el módulo insumos','insumos'),(1215,'2024-06-16 22:27:24',28,'inserción','Enrique ha insertado un nuevo elemento Alcohol Isopropílico en el módulo insumos','insumos'),(1216,'2024-06-16 22:28:17',28,'inserción','Enrique ha insertado un nuevo elemento alcohol en el módulo insumos','insumos'),(1217,'2024-06-16 22:28:21',28,'eliminación','Enrique ha eliminado al elemento id 11 en el módulo insumos','insumos'),(1218,'2024-06-19 01:47:36',32,'inserción','Aura ha insertado un nuevo elemento Traumatología en el módulo especialidad','especialidad'),(1219,'2024-06-19 01:47:54',32,'inserción','Aura ha insertado un nuevo elemento Psicología en el módulo especialidad','especialidad'),(1220,'2024-06-19 01:48:00',32,'inserción','Aura ha insertado un nuevo elemento Pediatría en el módulo especialidad','especialidad'),(1221,'2024-06-19 01:48:47',32,'inserción','Aura ha insertado un nuevo elemento Oncología en el módulo especialidad','especialidad'),(1222,'2024-06-19 01:48:52',32,'inserción','Aura ha insertado un nuevo elemento Otorrinolaringología en el módulo especialidad','especialidad'),(1223,'2024-06-19 01:48:56',32,'inserción','Aura ha insertado un nuevo elemento Oftamología en el módulo especialidad','especialidad'),(1224,'2024-06-19 01:49:09',32,'inserción','Aura ha insertado un nuevo elemento Cardiología en el módulo especialidad','especialidad'),(1225,'2024-06-19 01:49:39',32,'inserción','Aura ha insertado un nuevo elemento Dermatología en el módulo especialidad','especialidad'),(1226,'2024-06-19 01:49:48',32,'inserción','Aura ha insertado un nuevo elemento Gastroenterología en el módulo especialidad','especialidad'),(1227,'2024-06-19 01:49:57',32,'inserción','Aura ha insertado un nuevo elemento Endocrinología en el módulo especialidad','especialidad'),(1228,'2024-06-19 01:50:03',32,'inserción','Aura ha insertado un nuevo elemento Ortopedia en el módulo especialidad','especialidad'),(1229,'2024-06-19 01:50:09',32,'inserción','Aura ha insertado un nuevo elemento Psiquiatría en el módulo especialidad','especialidad'),(1230,'2024-06-19 01:50:25',32,'inserción','Aura ha insertado un nuevo elemento Fisioterapía en el módulo especialidad','especialidad'),(1231,'2024-06-19 01:50:55',32,'inserción','Aura ha insertado un nuevo elemento Ginecología en el módulo especialidad','especialidad'),(1232,'2024-06-19 01:51:05',32,'inserción','Aura ha insertado un nuevo elemento Acupuntura en el módulo especialidad','especialidad'),(1233,'2024-06-19 01:59:24',32,'inserción','Aura ha insertado un nuevo elemento Venda Elástica Adhesiva en el módulo insumos','insumos'),(1234,'2024-06-19 02:00:22',32,'inserción','Aura ha insertado un nuevo elemento Solución antiséptica en el módulo insumos','insumos'),(1235,'2024-06-19 02:01:10',32,'inserción','Aura ha insertado un nuevo elemento Jeringas desechables en el módulo insumos','insumos'),(1236,'2024-06-19 02:02:42',32,'inserción','Aura ha insertado un nuevo elemento Apósitos estériles en el módulo insumos','insumos'),(1237,'2024-06-19 02:04:08',32,'inserción','Aura ha insertado un nuevo elemento Gasas estériles en el módulo insumos','insumos'),(1238,'2024-06-19 02:05:45',32,'inserción','Aura ha insertado un nuevo elemento Aspirina  en el módulo insumos','insumos'),(1239,'2024-06-19 02:06:36',32,'inserción','Aura ha insertado un nuevo elemento Epinefrina en el módulo insumos','insumos'),(1240,'2024-06-19 02:07:23',32,'inserción','Aura ha insertado un nuevo elemento Diazepam pastillas en el módulo insumos','insumos'),(1241,'2024-06-19 02:07:41',32,'inserción','Aura ha insertado un nuevo elemento Diazepam ampollas en el módulo insumos','insumos'),(1242,'2024-06-19 02:08:25',32,'inserción','Aura ha insertado un nuevo elemento Amiodarona  en el módulo insumos','insumos'),(1243,'2024-06-19 02:08:29',32,'eliminación','Aura ha eliminado al elemento id 21 en el módulo insumos','insumos');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita`
--

DROP TABLE IF EXISTS `cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita` (
  `cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `fecha_cita` date NOT NULL,
  `hora_salida` time NOT NULL,
  `hora_entrada` time NOT NULL,
  `motivo_cita` varchar(45) NOT NULL,
  `cedula_titular` int(11) NOT NULL,
  `monto_aprobado` float NOT NULL,
  `tipo_cita` enum('1','2') NOT NULL,
  `tipo_servicio` enum('1','2') DEFAULT '1',
  `estatus_cit` enum('1','2','3','4',' 5') NOT NULL,
  PRIMARY KEY (`cita_id`),
  KEY `especialidad_id` (`especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `cita_ibfk_1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_ibfk_2` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_ibfk_3` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita`
--

LOCK TABLES `cita` WRITE;
/*!40000 ALTER TABLE `cita` DISABLE KEYS */;
/*!40000 ALTER TABLE `cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_examen`
--

DROP TABLE IF EXISTS `cita_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_examen` (
  `cita_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  `precio_examen_bs` float NOT NULL,
  `precio_examen_usd` float NOT NULL,
  `cubierto_por` enum('1','2','3') NOT NULL DEFAULT '1',
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto` float NOT NULL DEFAULT 0,
  `estatus_cit` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`cita_examen_id`),
  KEY `cita_id` (`cita_id`),
  KEY `examen_id` (`examen_id`),
  CONSTRAINT `cita_examen_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_examen_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_examen`
--

LOCK TABLES `cita_examen` WRITE;
/*!40000 ALTER TABLE `cita_examen` DISABLE KEYS */;
/*!40000 ALTER TABLE `cita_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_seguro`
--

DROP TABLE IF EXISTS `cita_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_seguro` (
  `cita_seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `clave` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`cita_seguro_id`),
  KEY `cita_id` (`cita_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `cita_seguro_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_seguro`
--

LOCK TABLES `cita_seguro` WRITE;
/*!40000 ALTER TABLE `cita_seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `cita_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra_insumo`
--

DROP TABLE IF EXISTS `compra_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra_insumo` (
  `compra_insumo_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `insumo_id` int(11) NOT NULL,
  `factura_compra_id` int(9) unsigned zerofill NOT NULL,
  `unidades` int(11) NOT NULL,
  `precio_unit_bs` float NOT NULL,
  `precio_total_bs` float NOT NULL,
  `precio_unit_usd` float NOT NULL,
  `precio_total_usd` float NOT NULL,
  PRIMARY KEY (`compra_insumo_id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `factura_compra_id` (`factura_compra_id`),
  CONSTRAINT `compra_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`insumo_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `compra_insumo_ibfk_2` FOREIGN KEY (`factura_compra_id`) REFERENCES `factura_compra` (`factura_compra_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra_insumo`
--

LOCK TABLES `compra_insumo` WRITE;
/*!40000 ALTER TABLE `compra_insumo` DISABLE KEYS */;
/*!40000 ALTER TABLE `compra_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta` (
  `consulta_id` int(11) NOT NULL AUTO_INCREMENT,
  `peso` float DEFAULT NULL,
  `altura` float DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `fecha_consulta` date NOT NULL,
  `es_emergencia` tinyint(1) NOT NULL DEFAULT 0,
  `tipo_servicio` enum('1','2') NOT NULL DEFAULT '1',
  `estatus_con` enum('1','2','3','4') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_cita`
--

DROP TABLE IF EXISTS `consulta_cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_cita` (
  `consulta_cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `consulta_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_cita_id`),
  KEY `cita_id` (`cita_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_cita_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_cita_ibfk_2` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_cita`
--

LOCK TABLES `consulta_cita` WRITE;
/*!40000 ALTER TABLE `consulta_cita` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_emergencia`
--

DROP TABLE IF EXISTS `consulta_emergencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_emergencia` (
  `consulta_emergencia_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `cedula_beneficiado` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `clave_seguro` int(11) NOT NULL,
  `cantidad_consultas_medicas` int(11) NOT NULL DEFAULT 0,
  `consultas_medicas` float NOT NULL,
  `consultas_medicas_bs` float NOT NULL,
  `cantidad_laboratorios` int(11) NOT NULL DEFAULT 0,
  `laboratorios` float DEFAULT NULL,
  `laboratorios_bs` float NOT NULL,
  `cantidad_medicamentos` int(11) NOT NULL DEFAULT 0,
  `medicamentos` float DEFAULT NULL,
  `medicamentos_bs` float NOT NULL,
  `area_observacion` float DEFAULT NULL,
  `area_observacion_bs` float NOT NULL,
  `enfermeria` float DEFAULT NULL,
  `enfermeria_bs` float NOT NULL,
  `total_insumos` float NOT NULL,
  `total_insumos_bs` float NOT NULL,
  `total_examenes` float NOT NULL,
  `total_examenes_bs` float NOT NULL,
  `total_consulta` float NOT NULL,
  `total_consulta_bs` float NOT NULL,
  `monto_aprobado` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `autorizacion` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`consulta_emergencia_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `consulta_emergencia_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_emergencia_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_emergencia_ibfk_3` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_emergencia`
--

LOCK TABLES `consulta_emergencia` WRITE;
/*!40000 ALTER TABLE `consulta_emergencia` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_emergencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_examen`
--

DROP TABLE IF EXISTS `consulta_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_examen` (
  `consulta_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  `precio_examen_bs` float NOT NULL,
  `precio_examen_usd` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `cubierto_por` enum('1','2','3') NOT NULL DEFAULT '1',
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`consulta_examen_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `examen_id` (`examen_id`),
  CONSTRAINT `consulta_examen_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_examen_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_examen`
--

LOCK TABLES `consulta_examen` WRITE;
/*!40000 ALTER TABLE `consulta_examen` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_indicaciones`
--

DROP TABLE IF EXISTS `consulta_indicaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_indicaciones` (
  `consulta_indicaciones_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`consulta_indicaciones_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_indicaciones_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_indicaciones`
--

LOCK TABLES `consulta_indicaciones` WRITE;
/*!40000 ALTER TABLE `consulta_indicaciones` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_indicaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_insumo`
--

DROP TABLE IF EXISTS `consulta_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_insumo` (
  `consulta_insumo_id` int(11) NOT NULL AUTO_INCREMENT,
  `insumo_id` int(11) NOT NULL,
  `consulta_id` int(11) NOT NULL,
  `cantidad` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `precio_insumo_bs` float NOT NULL,
  `precio_insumo_usd` float NOT NULL,
  PRIMARY KEY (`consulta_insumo_id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`insumo_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_insumo_ibfk_2` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_insumo`
--

LOCK TABLES `consulta_insumo` WRITE;
/*!40000 ALTER TABLE `consulta_insumo` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_recipe`
--

DROP TABLE IF EXISTS `consulta_recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_recipe` (
  `consulta_recipe_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `medicamento_id` int(11) NOT NULL,
  `uso` text NOT NULL,
  PRIMARY KEY (`consulta_recipe_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `medicamento_id` (`medicamento_id`),
  CONSTRAINT `consulta_recipe_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_recipe_ibfk_2` FOREIGN KEY (`medicamento_id`) REFERENCES `medicamento` (`medicamento_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_recipe`
--

LOCK TABLES `consulta_recipe` WRITE;
/*!40000 ALTER TABLE `consulta_recipe` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_referidos`
--

DROP TABLE IF EXISTS `consulta_referidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_referidos` (
  `consulta_referidos_id` int(9) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_referidos_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `consulta_referidos_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_referidos_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_referidos`
--

LOCK TABLES `consulta_referidos` WRITE;
/*!40000 ALTER TABLE `consulta_referidos` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_referidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_seguro`
--

DROP TABLE IF EXISTS `consulta_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_seguro` (
  `consulta_seguro_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `tipo_servicio` varchar(50) NOT NULL,
  `fecha_ocurrencia` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `monto_consulta_usd` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `monto_consulta_bs` float NOT NULL,
  `cobertura_seguro` float NOT NULL,
  PRIMARY KEY (`consulta_seguro_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `consulta_seguro_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_seguro`
--

LOCK TABLES `consulta_seguro` WRITE;
/*!40000 ALTER TABLE `consulta_seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_sin_cita`
--

DROP TABLE IF EXISTS `consulta_sin_cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_sin_cita` (
  `consulta_sin_cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_sin_cita_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `especialidad_id` (`especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `consulta_sin_cita_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_3` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_4` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_sin_cita`
--

LOCK TABLES `consulta_sin_cita` WRITE;
/*!40000 ALTER TABLE `consulta_sin_cita` DISABLE KEYS */;
/*!40000 ALTER TABLE `consulta_sin_cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `empresa_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `rif` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `estatus_emp` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`empresa_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidad` (
  `especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estatus_esp` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`especialidad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
INSERT INTO `especialidad` VALUES (11,'Traumatología','1'),(12,'Psicología','1'),(13,'Pediatría','1'),(14,'Oncología','1'),(15,'Otorrinolaringología','1'),(16,'Oftamología','1'),(17,'Cardiología','1'),(18,'Dermatología','1'),(19,'Gastroenterología','1'),(20,'Endocrinología','1'),(21,'Ortopedia','1'),(22,'Psiquiatría','1'),(23,'Fisioterapía','1'),(24,'Ginecología','1'),(25,'Acupuntura','1');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examen`
--

DROP TABLE IF EXISTS `examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examen` (
  `examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `precio_examen` int(11) DEFAULT NULL,
  `tipo` enum('1','2','3') NOT NULL,
  `estatus_exa` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`examen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examen`
--

LOCK TABLES `examen` WRITE;
/*!40000 ALTER TABLE `examen` DISABLE KEYS */;
/*!40000 ALTER TABLE `examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examen_especialidad`
--

DROP TABLE IF EXISTS `examen_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examen_especialidad` (
  `examen_especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `examen_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `estatus_exa` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`examen_especialidad_id`),
  KEY `examen_id` (`examen_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `examen_especialidad_ibfk_1` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `examen_especialidad_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examen_especialidad`
--

LOCK TABLES `examen_especialidad` WRITE;
/*!40000 ALTER TABLE `examen_especialidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `examen_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_compra`
--

DROP TABLE IF EXISTS `factura_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_compra` (
  `factura_compra_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `fecha_compra` datetime NOT NULL,
  `total_productos` int(11) NOT NULL,
  `monto_con_iva` float NOT NULL,
  `monto_sin_iva` float NOT NULL,
  `monto_usd` float NOT NULL,
  `excento` float DEFAULT NULL,
  `motivo_cancelacion` text DEFAULT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_compra_id`),
  KEY `proveedor_id` (`proveedor_id`),
  CONSTRAINT `factura_compra_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`proveedor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_compra`
--

LOCK TABLES `factura_compra` WRITE;
/*!40000 ALTER TABLE `factura_compra` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_consulta`
--

DROP TABLE IF EXISTS `factura_consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_consulta` (
  `factura_consulta_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `metodo_pago` varchar(20) NOT NULL,
  `monto_consulta_bs` float NOT NULL,
  `monto_consulta_usd` float NOT NULL,
  `tipo_consulta` enum('1','2') NOT NULL,
  `estatus_fac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_consulta_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `factura_consulta_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factura_consulta_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_consulta`
--

LOCK TABLES `factura_consulta` WRITE;
/*!40000 ALTER TABLE `factura_consulta` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_medico`
--

DROP TABLE IF EXISTS `factura_medico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_medico` (
  `factura_medico_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `acumulado_seguro_total` float DEFAULT NULL,
  `acumulado_consulta_total` float DEFAULT NULL,
  `sumatoria_consultas_aseguradas` float NOT NULL,
  `sumatoria_consultas_naturales` float NOT NULL,
  `acumulado_medico` float NOT NULL,
  `pago_total` float DEFAULT NULL,
  `factura_medico` float NOT NULL,
  `fecha_pago` date DEFAULT NULL,
  `fecha_emision` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pacientes_seguro` int(11) DEFAULT NULL,
  `pacientes_consulta` int(11) DEFAULT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_medico_id`),
  KEY `medico_id` (`medico_id`),
  CONSTRAINT `factura_medico_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_medico`
--

LOCK TABLES `factura_medico` WRITE;
/*!40000 ALTER TABLE `factura_medico` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_medico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_mensajeria`
--

DROP TABLE IF EXISTS `factura_mensajeria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_mensajeria` (
  `factura_mensajeria_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `fecha_mensajeria` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seguro_id` int(11) NOT NULL,
  `total_mensajeria_bs` float NOT NULL,
  `total_mensajeria_usd` float NOT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_mensajeria_id`),
  KEY `fk_mensajeria_seguro` (`seguro_id`),
  CONSTRAINT `fk_mensajeria_seguro` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_mensajeria`
--

LOCK TABLES `factura_mensajeria` WRITE;
/*!40000 ALTER TABLE `factura_mensajeria` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_mensajeria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_mensajeria_consultas`
--

DROP TABLE IF EXISTS `factura_mensajeria_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_mensajeria_consultas` (
  `factura_mensajeria_consultas_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `factura_mensajeria_id` int(9) unsigned zerofill NOT NULL,
  `consulta_seguro_id` int(9) unsigned zerofill NOT NULL,
  `fecha_mensajeria_consultas` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estatus_fac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_mensajeria_consultas_id`),
  KEY `fk_mensajeria_consultas` (`consulta_seguro_id`),
  KEY `factura_mensajeria_id` (`factura_mensajeria_id`),
  CONSTRAINT `factura_mensajeria_consultas_ibfk_1` FOREIGN KEY (`consulta_seguro_id`) REFERENCES `consulta_seguro` (`consulta_seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factura_mensajeria_consultas_ibfk_2` FOREIGN KEY (`factura_mensajeria_id`) REFERENCES `factura_mensajeria` (`factura_mensajeria_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_mensajeria_consultas`
--

LOCK TABLES `factura_mensajeria_consultas` WRITE;
/*!40000 ALTER TABLE `factura_mensajeria_consultas` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_mensajeria_consultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_seguro`
--

DROP TABLE IF EXISTS `factura_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_seguro` (
  `factura_seguro_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `seguro_id` int(11) NOT NULL,
  `nro_control` int(11) DEFAULT NULL,
  `mes` varchar(10) NOT NULL,
  `fecha_ocurrencia` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_vencimiento` date NOT NULL,
  `monto_usd` float NOT NULL,
  `monto_bs` float NOT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_seguro_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `factura_seguro_ibfk_1` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_seguro`
--

LOCK TABLES `factura_seguro` WRITE;
/*!40000 ALTER TABLE `factura_seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global`
--

DROP TABLE IF EXISTS `global`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global` (
  `global_id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`global_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global`
--

LOCK TABLES `global` WRITE;
/*!40000 ALTER TABLE `global` DISABLE KEYS */;
INSERT INTO `global` VALUES (1,'porcentaje_medico','40'),(2,'cambio_divisa','36.39'),(3,'porcentaje_insumo','5');
/*!40000 ALTER TABLE `global` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horario`
--

DROP TABLE IF EXISTS `horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horario` (
  `horario_id` int(11) NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `dias_semana` enum('lunes','martes','miercoles','jueves','viernes','sabado') NOT NULL,
  `hora_salida` time NOT NULL,
  `hora_entrada` time NOT NULL,
  `estatus_hor` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`horario_id`),
  KEY `medico_id` (`medico_id`),
  CONSTRAINT `horario_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horario`
--

LOCK TABLES `horario` WRITE;
/*!40000 ALTER TABLE `horario` DISABLE KEYS */;
/*!40000 ALTER TABLE `horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumo` (
  `insumo_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL DEFAULT '0',
  `cantidad_min` float NOT NULL,
  `cantidad_unidad` float NOT NULL DEFAULT 0,
  `capacidad_unidad` float NOT NULL,
  `cantidad_capacidad` float NOT NULL,
  `precio` float NOT NULL DEFAULT 0,
  `tipo_medida` enum('1','2','3','4') NOT NULL,
  `es_cobrado` enum('0','1') NOT NULL,
  `tipo_insumo` enum('1','2') DEFAULT '1',
  `estatus_ins` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`insumo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (9,'Alcohol Etílico',5000,0,2000,0,5,'2','1','1','1'),(10,'Alcohol Isopropílico',5000,0,2000,0,0,'2','0','1','1'),(11,'alcohol',2000,0,2000,0,0,'2','0','1','2'),(12,'Venda Elástica Adhesiva',5000,0,5000,0,0.8,'1','1','1','1'),(13,'Solución antiséptica',2000,0,1000,0,0.5,'2','1','1','1'),(14,'Jeringas desechables',20,0,100,0,1,'3','1','1','1'),(15,'Apósitos estériles',20,0,100,0,0.2,'3','1','1','1'),(16,'Gasas estériles',10,0,50,0,0.3,'3','1','1','1'),(17,'Aspirina',12,0,30,0,1,'3','1','2','1'),(18,'Epinefrina',8,0,1,0,2,'4','1','2','1'),(19,'Diazepam pastillas',12,0,20,0,1.2,'3','1','2','1'),(20,'Diazepam ampollas',6,0,1,0,1.5,'4','1','2','1'),(21,'Amiodarona',20,0,10,0,0.9,'3','1','2','2');
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicamento`
--

DROP TABLE IF EXISTS `medicamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicamento` (
  `medicamento_id` int(11) NOT NULL AUTO_INCREMENT,
  `especialidad_id` int(11) NOT NULL,
  `nombre_medicamento` varchar(45) NOT NULL,
  `tipo_medicamento` enum('1','2','3','4') DEFAULT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medicamento_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `medicamento_ibfk_1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicamento`
--

LOCK TABLES `medicamento` WRITE;
/*!40000 ALTER TABLE `medicamento` DISABLE KEYS */;
/*!40000 ALTER TABLE `medicamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico`
--

DROP TABLE IF EXISTS `medico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medico` (
  `medico_id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) NOT NULL,
  `acumulado` int(11) NOT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medico_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico`
--

LOCK TABLES `medico` WRITE;
/*!40000 ALTER TABLE `medico` DISABLE KEYS */;
/*!40000 ALTER TABLE `medico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico_especialidad`
--

DROP TABLE IF EXISTS `medico_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medico_especialidad` (
  `medico_especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `costo_especialidad` int(11) NOT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medico_especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `medico_especialidad_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `medico_especialidad_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico_especialidad`
--

LOCK TABLES `medico_especialidad` WRITE;
/*!40000 ALTER TABLE `medico_especialidad` DISABLE KEYS */;
/*!40000 ALTER TABLE `medico_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente` (
  `paciente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` int(11) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) NOT NULL,
  `tipo_paciente` enum('1','2','3','4') NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=95 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente`
--

LOCK TABLES `paciente` WRITE;
/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente_beneficiado`
--

DROP TABLE IF EXISTS `paciente_beneficiado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente_beneficiado` (
  `paciente_beneficiado_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_beneficiado_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `paciente_beneficiado_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente_beneficiado`
--

LOCK TABLES `paciente_beneficiado` WRITE;
/*!40000 ALTER TABLE `paciente_beneficiado` DISABLE KEYS */;
/*!40000 ALTER TABLE `paciente_beneficiado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente_seguro`
--

DROP TABLE IF EXISTS `paciente_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente_seguro` (
  `paciente_seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `tipo_seguro` enum('1','2') NOT NULL,
  `cobertura_general` float NOT NULL,
  `fecha_contra` date NOT NULL,
  `saldo_disponible` float NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_seguro_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `seguro_id` (`seguro_id`),
  KEY `empresa_id` (`empresa_id`),
  CONSTRAINT `paciente_seguro_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paciente_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paciente_seguro_ibfk_3` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`empresa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente_seguro`
--

LOCK TABLES `paciente_seguro` WRITE;
/*!40000 ALTER TABLE `paciente_seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `paciente_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregunta_seguridad`
--

DROP TABLE IF EXISTS `pregunta_seguridad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pregunta_seguridad` (
  `pregunta_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `pregunta` varchar(100) NOT NULL,
  `respuesta` varchar(100) NOT NULL,
  `estatus_pre` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`pregunta_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `pregunta_seguridad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregunta_seguridad`
--

LOCK TABLES `pregunta_seguridad` WRITE;
/*!40000 ALTER TABLE `pregunta_seguridad` DISABLE KEYS */;
INSERT INTO `pregunta_seguridad` VALUES (31,27,'1','amarillo','1'),(32,27,'2','rocky','1'),(33,27,'3','perez','1'),(34,28,'1','rojo','1'),(35,28,'5','jugar','1'),(36,28,'8','limon','1'),(37,29,'1','amarillo','1'),(38,29,'2','rocky','1'),(39,29,'3','perez','1'),(40,30,'1','amarillo','1'),(41,30,'2','rocky','1'),(42,30,'5','dibujar','1'),(43,31,'1','amarillo','1'),(44,31,'3','perez','1'),(45,31,'4','guayaba','1'),(46,32,'1','amarillo','1'),(47,32,'3','perez','1'),(48,32,'8','limon','1');
/*!40000 ALTER TABLE `pregunta_seguridad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `proveedor_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `ubicacion` varchar(255) NOT NULL,
  `estatus_pro` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`proveedor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro`
--

DROP TABLE IF EXISTS `seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro` (
  `seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `rif` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `telefono` varchar(13) NOT NULL,
  `porcentaje` int(11) NOT NULL,
  `costo_consulta` int(11) NOT NULL,
  `maximo_dias` int(11) NOT NULL DEFAULT 15,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro`
--

LOCK TABLES `seguro` WRITE;
/*!40000 ALTER TABLE `seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro_empresa`
--

DROP TABLE IF EXISTS `seguro_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro_empresa` (
  `seguro_empresa_id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_empresa_id`),
  KEY `empresa_id` (`empresa_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `seguro_empresa_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`empresa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `seguro_empresa_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro_empresa`
--

LOCK TABLES `seguro_empresa` WRITE;
/*!40000 ALTER TABLE `seguro_empresa` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguro_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro_examen`
--

DROP TABLE IF EXISTS `seguro_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro_examen` (
  `seguro_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `seguro_id` int(11) NOT NULL,
  `examenes` text NOT NULL,
  `costos` text NOT NULL,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_examen_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `seguro_examen_ibfk_1` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro_examen`
--

LOCK TABLES `seguro_examen` WRITE;
/*!40000 ALTER TABLE `seguro_examen` DISABLE KEYS */;
/*!40000 ALTER TABLE `seguro_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_antecedente`
--

DROP TABLE IF EXISTS `tipo_antecedente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_antecedente` (
  `tipo_antecedente_id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `estatus_tip` enum('1','2') NOT NULL,
  PRIMARY KEY (`tipo_antecedente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_antecedente`
--

LOCK TABLES `tipo_antecedente` WRITE;
/*!40000 ALTER TABLE `tipo_antecedente` DISABLE KEYS */;
INSERT INTO `tipo_antecedente` VALUES (1,'Antecedentes Patológicos','2023-05-28 23:51:47','1'),(2,'Antecedentes Psicológicos','2023-05-28 23:51:47','1'),(3,'Antecedentes médicos familiares','2023-05-28 23:51:47','1'),(4,'Cirugías o traumatismos','2023-05-28 23:51:47','1'),(5,'Alergias','2023-05-28 23:51:47','1'),(6,'Reacción a medicamentos','2023-05-28 23:51:47','1'),(7,'Enfermedades Padecidas','2023-05-28 23:51:47','1'),(8,'Tratamientos','2023-05-28 23:51:47','1'),(9,'Hábitos de salud','2023-05-28 00:00:00','1');
/*!40000 ALTER TABLE `tipo_antecedente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titular_beneficiado`
--

DROP TABLE IF EXISTS `titular_beneficiado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titular_beneficiado` (
  `titular_beneficiado_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_beneficiado_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `estatus_tit` enum('1','2') NOT NULL DEFAULT '1',
  `tipo_relacion` enum('1','2') NOT NULL,
  `tipo_familiar` enum('1','2','3','4',' 5','6') NOT NULL,
  PRIMARY KEY (`titular_beneficiado_id`),
  KEY `paciente_beneficiado_id` (`paciente_beneficiado_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `titular_beneficiado_ibfk_1` FOREIGN KEY (`paciente_beneficiado_id`) REFERENCES `paciente_beneficiado` (`paciente_beneficiado_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `titular_beneficiado_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titular_beneficiado`
--

LOCK TABLES `titular_beneficiado` WRITE;
/*!40000 ALTER TABLE `titular_beneficiado` DISABLE KEYS */;
/*!40000 ALTER TABLE `titular_beneficiado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(40) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `nombre` varchar(16) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `tokken` varchar(10) DEFAULT NULL,
  `intentos` varchar(10) DEFAULT NULL,
  `rol` int(11) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `estatus_usu` enum('1','2') NOT NULL DEFAULT '2',
  `fecha_creacion` datetime NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=33 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (27,'Oriana Carolina','Blanco','Oriana','$2y$10$npllQrVRnuLbFIHvxiOa2uP13oqQG6ZZdUWS9y6OPNozTNg5rA582','bd976d6734',NULL,2,'$2y$10$k0KKtlyCGVNXwNpG.kkZPemjBb/6ydpsAyEGaWeWoOtShJTKSHUEK','1','2024-06-16 11:23:53'),(28,'Enrique Miguel','Chacón Almérida','Enrique','$2y$10$qEVK5ihd69g7PrFYJLRfruBFxQErNrUf1vyb.yh8Rbn.X6nduJOYu','1c7f47d7e7','3|08:44',1,'$2y$10$.WbJBGNLaebuQ0Y2o/Rk3.MipHi8kN9Uz/Kq6ii4yo5.lfQ2WwwP','1','2024-06-16 11:24:54'),(29,'Francis Mayini','Baloa Coronado','Francis','$2y$10$D9RZvFwP7i1rpFrkxlXK7.11WtMSvzD.XDMPkxXSkivtG.XDUkXCy','13d00f3be5',NULL,4,'$2y$10$Sk/go279YbV8HQYdSKB8B.yGyBcM5O/AEZMMQBJxWz2ojFxPYGnt6','1','2024-06-16 11:26:00'),(30,'Angelica María','Alvarado Perez','Angelica','$2y$10$iwx0G2pGNrTnp9nzv6SYHOiSjU6507xsxs.PDU98cWvj4r1Edv04S',NULL,NULL,4,'$2y$10$BJO533SO38hewjL2tX5KbOAquKXB4rFAzmYYN65x6bFektWcYCb9G','1','2024-06-16 11:26:48'),(31,'Gloria Carmen','Sanchez García','Rosa','$2y$10$/ac4AKoYK5UXIzbBMw7u/eromKYPkeCpcDMscdyUs4vYH43O6gyTa',NULL,NULL,5,'$2y$10$2epn.lpBXcuk20rupAUa2.4syXT3aG.UJkfbw0kjuDkYVyZ8cdZGq','1','2024-06-16 11:27:48'),(32,'Aura','Mendoza','Aura','$2y$10$PQVk/xOw.wg/YXfqy9FHXePQ7AHbRR55iUEHEd6cZYWN7jmtdONkS','2f8f4a0f45',NULL,1,'$2y$10$KheCMhFLn6UozTFc3KpOU.RLNHiygoSeB09mK8rZBaeejJZD4fN4a','1','2024-06-16 11:36:25');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-06-19 11:38:34
