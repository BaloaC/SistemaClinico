-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: shenque_db
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `antecedentes_medicos`
--

DROP TABLE IF EXISTS `antecedentes_medicos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `antecedentes_medicos` (
  `antecedentes_medicos_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `tipo_antecedente_id` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  `estatus_ant` enum('1','2') NOT NULL DEFAULT '1',
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`antecedentes_medicos_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `tipo_antecedente_id` (`tipo_antecedente_id`),
  CONSTRAINT `antecedentes_medicos_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `antecedentes_medicos_ibfk_2` FOREIGN KEY (`tipo_antecedente_id`) REFERENCES `tipo_antecedente` (`tipo_antecedente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `antecedentes_medicos`
--

LOCK TABLES `antecedentes_medicos` WRITE;
/*!40000 ALTER TABLE `antecedentes_medicos` DISABLE KEYS */;
INSERT INTO `antecedentes_medicos` VALUES (4,113,1,'Operado a los 7 años de las admígdalas','1','2024-07-09 04:29:52'),(5,101,1,'123','2','2024-07-10 19:16:38');
/*!40000 ALTER TABLE `antecedentes_medicos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auditoria`
--

DROP TABLE IF EXISTS `auditoria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `auditoria` (
  `auditoria_id` int(11) NOT NULL AUTO_INCREMENT,
  `fecha_creacion` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `usuario_id` int(11) NOT NULL,
  `accion` varchar(45) NOT NULL,
  `descripcion` varchar(255) NOT NULL,
  `modulo` varchar(30) NOT NULL,
  PRIMARY KEY (`auditoria_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1403 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auditoria`
--

LOCK TABLES `auditoria` WRITE;
/*!40000 ALTER TABLE `auditoria` DISABLE KEYS */;
INSERT INTO `auditoria` VALUES (1209,'2024-06-20 12:25:09',32,'actualización','Francis ha habilitado al usuario Oriana Carolina en el módulo usuarios','usuarios'),(1210,'2024-06-20 12:25:22',32,'actualización','Francis ha habilitado al usuario Enrique Miguel en el módulo usuarios','usuarios'),(1211,'2024-06-20 12:25:36',32,'actualización','Francis ha habilitado al usuario Francis Mayini en el módulo usuarios','usuarios'),(1212,'2024-06-20 12:25:45',32,'actualización','Francis ha habilitado al usuario Angelica María en el módulo usuarios','usuarios'),(1213,'2024-06-20 12:25:58',32,'actualización','Francis ha habilitado al usuario Gloria Carmen en el módulo usuarios','usuarios'),(1214,'2024-06-16 22:26:30',28,'inserción','Enrique ha insertado un nuevo elemento Alcohol Etílico en el módulo insumos','insumos'),(1215,'2024-06-16 22:27:24',28,'inserción','Enrique ha insertado un nuevo elemento Alcohol Isopropílico en el módulo insumos','insumos'),(1216,'2024-06-16 22:28:17',28,'inserción','Enrique ha insertado un nuevo elemento alcohol en el módulo insumos','insumos'),(1217,'2024-06-20 15:45:40',28,'eliminación','Enrique ha eliminado al elemento alcohol en el módulo insumos','insumos'),(1218,'2024-06-19 01:47:36',32,'inserción','Aura ha insertado un nuevo elemento Traumatología en el módulo especialidad','especialidad'),(1219,'2024-06-19 01:47:54',32,'inserción','Aura ha insertado un nuevo elemento Psicología en el módulo especialidad','especialidad'),(1220,'2024-06-19 01:48:00',32,'inserción','Aura ha insertado un nuevo elemento Pediatría en el módulo especialidad','especialidad'),(1221,'2024-06-19 01:48:47',32,'inserción','Aura ha insertado un nuevo elemento Oncología en el módulo especialidad','especialidad'),(1222,'2024-06-19 01:48:52',32,'inserción','Aura ha insertado un nuevo elemento Otorrinolaringología en el módulo especialidad','especialidad'),(1223,'2024-06-19 01:48:56',32,'inserción','Aura ha insertado un nuevo elemento Oftamología en el módulo especialidad','especialidad'),(1224,'2024-06-19 01:49:09',32,'inserción','Aura ha insertado un nuevo elemento Cardiología en el módulo especialidad','especialidad'),(1225,'2024-06-19 01:49:39',32,'inserción','Aura ha insertado un nuevo elemento Dermatología en el módulo especialidad','especialidad'),(1226,'2024-06-19 01:49:48',32,'inserción','Aura ha insertado un nuevo elemento Gastroenterología en el módulo especialidad','especialidad'),(1227,'2024-06-19 01:49:57',32,'inserción','Aura ha insertado un nuevo elemento Endocrinología en el módulo especialidad','especialidad'),(1228,'2024-06-19 01:50:03',32,'inserción','Aura ha insertado un nuevo elemento Ortopedia en el módulo especialidad','especialidad'),(1229,'2024-06-19 01:50:09',32,'inserción','Aura ha insertado un nuevo elemento Psiquiatría en el módulo especialidad','especialidad'),(1230,'2024-06-19 01:50:25',32,'inserción','Aura ha insertado un nuevo elemento Fisioterapía en el módulo especialidad','especialidad'),(1231,'2024-06-19 01:50:55',32,'inserción','Aura ha insertado un nuevo elemento Ginecología en el módulo especialidad','especialidad'),(1232,'2024-06-19 01:51:05',32,'inserción','Aura ha insertado un nuevo elemento Acupuntura en el módulo especialidad','especialidad'),(1233,'2024-06-19 01:59:24',32,'inserción','Aura ha insertado un nuevo elemento Venda Elástica Adhesiva en el módulo insumos','insumos'),(1234,'2024-06-19 02:00:22',32,'inserción','Aura ha insertado un nuevo elemento Solución antiséptica en el módulo insumos','insumos'),(1235,'2024-06-19 02:01:10',32,'inserción','Aura ha insertado un nuevo elemento Jeringas desechables en el módulo insumos','insumos'),(1236,'2024-06-19 02:02:42',32,'inserción','Aura ha insertado un nuevo elemento Apósitos estériles en el módulo insumos','insumos'),(1237,'2024-06-19 02:04:08',32,'inserción','Aura ha insertado un nuevo elemento Gasas estériles en el módulo insumos','insumos'),(1238,'2024-06-19 02:05:45',32,'inserción','Aura ha insertado un nuevo elemento Aspirina  en el módulo insumos','insumos'),(1239,'2024-06-19 02:06:36',32,'inserción','Aura ha insertado un nuevo elemento Epinefrina en el módulo insumos','insumos'),(1240,'2024-06-19 02:07:23',32,'inserción','Aura ha insertado un nuevo elemento Diazepam pastillas en el módulo insumos','insumos'),(1241,'2024-06-19 02:07:41',32,'inserción','Aura ha insertado un nuevo elemento Diazepam ampollas en el módulo insumos','insumos'),(1242,'2024-06-19 02:08:25',32,'inserción','Aura ha insertado un nuevo elemento Amiodarona  en el módulo insumos','insumos'),(1243,'2024-06-20 12:36:57',32,'eliminación','Aura ha eliminado al elemento Amiodarona en el módulo insumos','insumos'),(1244,'2024-06-20 12:41:18',27,'inserción','Oriana ha insertado un nuevo elemento Juan Gabriel en el módulo médicos','médicos'),(1245,'2024-06-20 12:42:27',27,'inserción','Oriana ha insertado un nuevo elemento Medicina General en el módulo especialidad','especialidad'),(1246,'2024-06-20 12:47:21',27,'inserción','Oriana ha insertado un nuevo elemento Rosa María en el módulo médicos','médicos'),(1247,'2024-06-20 14:12:26',27,'inserción','Oriana ha insertado un nuevo elemento Juan Francisco en el módulo médicos','médicos'),(1248,'2024-06-20 15:15:28',32,'inserción','Aura ha insertado un nuevo elemento María del Carmen en el módulo médicos','médicos'),(1249,'2024-06-20 15:18:15',32,'inserción','Aura ha insertado un nuevo elemento Luis Fernando en el módulo médicos','médicos'),(1251,'2024-06-20 15:48:07',32,'inserción','Aura ha insertado un nuevo elemento Rafael Antonio en el módulo médicos','médicos'),(1252,'2024-06-20 16:11:19',32,'actualización','Aura ha deshabilitado al usuario Oriana Carolina en el módulo usuarios','usuarios'),(1253,'2024-06-20 16:11:32',32,'actualización','Aura ha habilitado al usuario Oriana Carolina en el módulo usuarios','usuarios'),(1254,'2024-06-21 13:02:33',27,'inserción','Oriana ha insertado un nuevo elemento Manuel Antonio en el módulo médicos','médicos'),(1255,'2024-06-21 13:04:33',27,'inserción','Oriana ha insertado un nuevo elemento Juan Fernando en el módulo médicos','médicos'),(1256,'2024-06-21 14:09:56',27,'inserción','Oriana ha insertado un nuevo elemento Antonio Miguel en el módulo médicos','médicos'),(1257,'2024-06-21 14:13:03',27,'inserción','Oriana ha insertado un nuevo elemento Luis Alejandro en el módulo médicos','médicos'),(1258,'2024-06-22 18:18:15',27,'inserción','Oriana ha insertado un nuevo elemento Juana Angela en el módulo médicos','médicos'),(1259,'2024-06-22 18:24:24',27,'inserción','Oriana ha insertado un nuevo elemento María de los Angeles en el módulo médicos','médicos'),(1260,'2024-06-22 18:44:30',32,'actualización','Aura ha actualizado al elemento Juana Angelina los campos nombre en el módulo medicos','medicos'),(1261,'2024-06-22 18:46:22',32,'actualización','Aura ha actualizado al elemento Juana Angelina los campos hora_inicio_jueves, hora_salida_jueves en el módulo medicos','medicos'),(1262,'2024-06-22 18:49:00',32,'actualización','Aura ha actualizado al elemento Medicina Genera los campos nombre en el módulo especialidad','especialidad'),(1263,'2024-06-22 18:49:19',32,'actualización','Aura ha actualizado al elemento Medicina General los campos nombre en el módulo especialidad','especialidad'),(1264,'2024-06-22 19:38:36',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Ibuprofeno 400 mg','medicamentos'),(1265,'2024-06-22 19:38:42',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Acetaminofen 500 mg','medicamentos'),(1266,'2024-06-22 19:38:46',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Montelukast 10 mg','medicamentos'),(1267,'2024-06-22 19:38:50',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Losartán Potásico 100 mg','medicamentos'),(1268,'2024-06-22 19:38:57',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Metolazona 2,5 mg','medicamentos'),(1269,'2024-06-22 19:39:06',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Jarabe llamado Prednisona','medicamentos'),(1270,'2024-06-22 19:39:15',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Metocarbamol 750 mg','medicamentos'),(1271,'2024-06-22 19:48:55',32,'inserción','Aura ha insertado un nuevo elemento Ecocardiograma en el módulo exámenes','exámenes'),(1272,'2024-06-22 20:07:57',32,'inserción','Aura ha insertado un nuevo elemento Resonancia magnética del corazón en el módulo exámenes','exámenes'),(1273,'2024-06-22 20:17:42',32,'inserción','Aura ha insertado un nuevo elemento Artrocentesis en el módulo exámenes','exámenes'),(1274,'2024-06-22 20:20:07',32,'inserción','Aura ha insertado un nuevo elemento biopsia cutánea en el módulo exámenes','exámenes'),(1275,'2024-06-22 20:24:32',32,'inserción','Aura ha insertado un nuevo elemento Prick Test en el módulo exámenes','exámenes'),(1276,'2024-06-22 20:27:52',32,'inserción','Aura ha insertado un nuevo elemento Audiometría en el módulo exámenes','exámenes'),(1277,'2024-06-22 20:28:10',32,'inserción','Aura ha insertado un nuevo elemento Timpanometría en el módulo exámenes','exámenes'),(1278,'2024-06-22 20:28:53',32,'inserción','Aura ha insertado un nuevo elemento Refracción en el módulo exámenes','exámenes'),(1279,'2024-06-22 20:29:21',32,'inserción','Aura ha insertado un nuevo elemento Paquimetríal en el módulo exámenes','exámenes'),(1280,'2024-06-22 20:29:45',32,'actualización','Aura ha actualizado al elemento Paquimetría los campos nombre en el módulo exámenes','exámenes'),(1281,'2024-06-22 20:31:42',32,'inserción','Aura ha insertado un nuevo elemento Ultrasonidos del Abdomen en el módulo exámenes','exámenes'),(1282,'2024-06-22 20:32:03',32,'inserción','Aura ha insertado un nuevo elemento Escaneo de tiroides en el módulo exámenes','exámenes'),(1283,'2024-06-22 20:32:42',32,'inserción','Aura ha insertado un nuevo elemento HbA1c azúcar en sangre en el módulo exámenes','exámenes'),(1284,'2024-06-22 20:33:15',32,'inserción','Aura ha insertado un nuevo elemento Endoscopia gastrointestinal en el módulo exámenes','exámenes'),(1285,'2024-06-22 20:33:34',32,'inserción','Aura ha insertado un nuevo elemento Colonoscopia en el módulo exámenes','exámenes'),(1286,'2024-06-22 20:34:15',32,'inserción','Aura ha insertado un nuevo elemento Citología en el módulo exámenes','exámenes'),(1287,'2024-06-22 20:34:30',32,'inserción','Aura ha insertado un nuevo elemento Ecografía vaginal en el módulo exámenes','exámenes'),(1288,'2024-06-22 20:35:23',32,'inserción','Aura ha insertado un nuevo elemento Mamografía en el módulo exámenes','exámenes'),(1289,'2024-06-23 19:04:45',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Jarabe llamado Altretamina','medicamentos'),(1290,'2024-06-23 19:09:49',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Inyección llamado Busulfan','medicamentos'),(1291,'2024-06-23 19:11:19',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Inyección llamado Carmustina 100 mg','medicamentos'),(1292,'2024-06-23 19:29:07',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Omeprazol 20 mg','medicamentos'),(1293,'2024-06-23 19:30:27',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Inyección llamado Ranitidina 50 mg','medicamentos'),(1294,'2024-06-23 19:32:07',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Solución llamado Enterogermina','medicamentos'),(1295,'2024-06-23 19:32:56',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Artrovit','medicamentos'),(1296,'2024-06-23 19:47:26',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Levotiroxina Sódica 50 mg','medicamentos'),(1297,'2024-06-23 19:49:32',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Amlodipina 10 mg','medicamentos'),(1298,'2024-06-23 19:51:50',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Aciclovir','medicamentos'),(1299,'2024-06-23 19:53:05',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Sertralina 50 mg','medicamentos'),(1300,'2024-06-23 19:54:38',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Desloratadina 40 mg','medicamentos'),(1301,'2024-06-23 19:55:02',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado ketroprofeno 100 mg','medicamentos'),(1302,'2024-06-23 19:57:32',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Cápsula llamado Metimazol 100 mg','medicamentos'),(1303,'2024-06-23 20:01:30',27,'inserción','El usuario Oriana insertó un nuevo medicamento de tipo Gotas llamado Fanasal','medicamentos'),(1304,'2024-06-23 20:11:25',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Gotas llamado Airfren 15 ml','medicamentos'),(1305,'2024-06-23 20:13:32',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Gotas llamado Fisiolin','medicamentos'),(1306,'2024-06-23 20:14:44',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Crema/Loción llamado Clotrimazol','medicamentos'),(1307,'2024-06-23 20:16:07',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Crema/Loción llamado Dermosupril','medicamentos'),(1308,'2024-06-23 20:16:43',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Crema/Loción llamado Baycuten','medicamentos'),(1309,'2024-06-23 20:17:38',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Crema/Loción llamado Dermazol 0,05','medicamentos'),(1310,'2024-06-23 20:23:33',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Gotas llamado Dextran','medicamentos'),(1311,'2024-06-23 20:26:21',32,'inserción','El usuario Aura insertó un nuevo medicamento de tipo Cápsula llamado Oftagen','medicamentos'),(1312,'2024-06-23 20:44:37',32,'actualización','El usuario Aura actualizó el medicamento Enterogermina','medicamentos'),(1313,'2024-06-23 20:41:07',32,'inserción','Aura ha insertado un nuevo elemento Maria Carolina en el módulo pacientes','pacientes'),(1314,'2024-06-23 20:43:14',32,'inserción','Aura ha insertado un nuevo elemento Juan David en el módulo pacientes','pacientes'),(1315,'2024-06-23 20:43:59',32,'inserción','Aura ha insertado un nuevo elemento Luis Miguel en el módulo pacientes','pacientes'),(1316,'2024-06-23 20:45:30',32,'inserción','Aura ha insertado un nuevo elemento Miguelangel en el módulo pacientes','pacientes'),(1317,'2024-06-23 20:46:30',32,'inserción','Aura ha insertado un nuevo elemento Luz del Carmen en el módulo pacientes','pacientes'),(1324,'2024-06-23 23:16:47',31,'inserción','Rosa ha insertado un nuevo elemento Juan Carlos en el módulo pacientes','pacientes'),(1325,'2024-06-23 23:57:07',27,'inserción','Oriana ha insertado un nuevo elemento Seguros La Previsora en el módulo seguros','seguros'),(1327,'2024-06-24 00:18:22',27,'inserción','Oriana ha insertado un nuevo elemento Seguros Horizonte S.A en el módulo seguros','seguros'),(1328,'2024-06-24 00:21:43',27,'inserción','Oriana ha insertado un nuevo elemento Banesco Seguros en el módulo seguros','seguros'),(1329,'2024-06-24 00:29:10',27,'inserción','Oriana ha insertado un nuevo elemento Seguros Venezuela en el módulo seguros','seguros'),(1330,'2024-06-24 00:50:21',27,'inserción','Oriana ha insertado un nuevo elemento Seguros Pirámides en el módulo seguros','seguros'),(1331,'2024-06-24 00:52:55',27,'inserción','Oriana ha insertado un nuevo elemento Seguros Qualitas en el módulo seguros','seguros'),(1332,'2024-06-24 12:00:15',32,'inserción','Aura ha insertado un nuevo elemento Vasos Venezolanos C.A. en el módulo empresas','empresas'),(1333,'2024-06-24 12:05:28',32,'inserción','Aura ha insertado un nuevo elemento Manufacturas de Papel C.A. en el módulo empresas','empresas'),(1334,'2024-06-24 14:20:04',32,'inserción','Aura ha insertado un nuevo elemento Inversiones Selva C.A. en el módulo empresas','empresas'),(1335,'2024-06-24 14:41:29',32,'inserción','Aura ha insertado un nuevo elemento Panaven C.A. en el módulo empresas','empresas'),(1336,'2024-06-24 19:40:36',27,'inserción','Oriana ha insertado un nuevo elemento Grupo Farma en el módulo empresas','empresas'),(1337,'2024-06-24 20:38:00',32,'inserción','Aura ha insertado un nuevo elemento David Miguel en el módulo pacientes','pacientes'),(1338,'2024-06-24 20:39:33',32,'inserción','Aura ha insertado un nuevo elemento Luis Angel en el módulo pacientes','pacientes'),(1339,'2024-07-09 03:38:09',32,'inserción','Aura ha insertado un nuevo elemento Rosalía Ana en el módulo pacientes','pacientes'),(1340,'2024-06-24 20:48:31',32,'inserción','Aura ha insertado un nuevo elemento Juan Diego en el módulo pacientes','pacientes'),(1341,'2024-06-24 20:54:00',32,'inserción','Aura ha insertado un nuevo elemento Ana Carmen en el módulo pacientes','pacientes'),(1342,'2024-06-24 20:55:55',32,'inserción','Aura ha insertado un nuevo elemento Angela Nora en el módulo pacientes','pacientes'),(1343,'2024-06-24 20:57:00',32,'inserción','Aura ha insertado un nuevo elemento Luisa Daniela en el módulo pacientes','pacientes'),(1344,'2024-06-24 20:58:20',32,'inserción','Aura ha insertado un nuevo elemento Wendy Carmiña en el módulo pacientes','pacientes'),(1345,'2024-06-25 20:09:45',31,'inserción','Rosa ha insertado un nuevo elemento Sarai Angela en el módulo pacientes','pacientes'),(1346,'2024-06-25 20:25:47',31,'inserción','Rosa ha insertado un nuevo elemento María de los Ángeles en el módulo pacientes','pacientes'),(1347,'2024-06-26 19:12:23',31,'inserción','Rosa ha insertado un nuevo elemento Ana Angelica en el módulo pacientes','pacientes'),(1348,'2024-06-26 20:33:01',31,'inserción','Rosa ha insertado un nuevo elemento Rosa Angelica en el módulo pacientes','pacientes'),(1349,'2024-06-26 20:34:14',31,'inserción','Rosa ha insertado un nuevo elemento Daniel Enrique en el módulo pacientes','pacientes'),(1350,'2024-06-26 20:58:19',28,'inserción','Enrique ha insertado un nuevo elemento Grupo Farma en el módulo proveedores','proveedores'),(1351,'2024-06-26 20:58:30',28,'inserción','Enrique ha insertado un nuevo elemento Suplementos Médicos C.A. en el módulo proveedores','proveedores'),(1352,'2024-06-26 20:59:15',28,'inserción','Enrique ha insertado un nuevo elemento Insumos Maracay C.A. en el módulo proveedores','proveedores'),(1353,'2024-06-26 20:59:27',28,'actualización','Enrique ha actualizado al elemento Grupo Farma C.A los campos nombre en el módulo proveedores','proveedores'),(1354,'2024-06-28 02:22:47',28,'inserción','El usuario Enrique insertó la orden de compra con id 000000001','recibo de compra'),(1355,'2024-06-28 02:22:43',28,'inserción','El usuario Enrique insertó la orden de compra con id 000000002','recibo de compra'),(1356,'2024-06-28 02:22:39',28,'inserción','El usuario Enrique insertó la orden de compra con id 000000003','recibo de compra'),(1357,'2024-06-28 02:22:34',28,'inserción','El usuario Enrique insertó la orden de compra con id 000000004','recibo de compra'),(1358,'2024-06-27 20:27:43',32,'inserción','Aura ha insertado un nuevo elemento Olga María en el módulo pacientes','pacientes'),(1359,'2024-06-27 20:31:01',32,'inserción','Aura ha insertado un nuevo elemento Juan Diego en el módulo pacientes','pacientes'),(1360,'2024-06-27 20:40:39',32,'inserción','Aura ha insertado un nuevo elemento Diana Miranda en el módulo pacientes','pacientes'),(1361,'2024-06-27 21:10:19',31,'inserción','El usuario Rosa insertó una cita normal para el paciente Maria Carolina Guerrera Rojas','citas'),(1362,'2024-06-27 21:12:54',31,'inserción','El usuario Rosa insertó una cita normal para el paciente Miguelangel Flores Carrillo','citas'),(1363,'2024-06-27 21:29:34',31,'inserción','El usuario Rosa insertó una cita asegurada para el paciente David Miguel Mijares Sanchez','citas'),(1364,'2024-06-27 21:35:01',27,'inserción','El usuario Oriana reprogramó la cita id 7 del día 2024-06-26 del paciente Maria Carolina Guerrera Rojas a la fecha 2024-07-02','citas'),(1365,'2024-06-30 11:51:07',27,'inserción','El usuario Oriana reprogramó la cita id 8 del día 2024-06-28 del paciente Maria Carolina Guerrera Rojas a la fecha 2024-07-04','citas'),(1366,'2024-06-30 11:53:31',27,'inserción','El usuario Oriana reprogramó la cita id 9 del día 2024-06-28 del paciente Miguelangel Flores Carrillo a la fecha 2024-07-04','citas'),(1367,'2024-06-30 11:54:30',27,'inserción','El usuario Oriana reprogramó la cita id 10 del día 2024-06-28 del paciente David Miguel Mijares Sanchez a la fecha 2024-07-03','citas'),(1368,'2024-06-30 12:34:39',27,'inserción','El usuario Oriana insertó la consulta natural del paciente con cédula 15984263','consultas'),(1369,'2024-06-30 16:02:51',27,'inserción','El usuario Oriana insertó la consulta natural del paciente con cédula 28475431','consultas'),(1370,'2024-06-30 19:25:18',27,'inserción','El usuario Oriana insertó la consulta por emergencia del paciente con cédula 18451236','consultas'),(1371,'2024-07-01 20:45:17',28,'inserción','El usuario Enrique insertó la orden de consulta con id 000000001','recibo de consulta'),(1372,'2024-07-01 21:11:52',27,'inserción','El usuario Oriana insertó la orden de consulta con id 000000002','recibo de consulta'),(1373,'2024-07-01 21:37:22',28,'inserción','El usuario Enrique insertó la orden de asegurada con id 000000001','recibo de asegurada'),(1374,'2024-07-02 19:02:31',31,'inserción','El usuario Rosa insertó la consulta natural del paciente con cédula 23546543','consultas'),(1375,'2024-07-02 19:27:51',31,'inserción','El usuario Rosa insertó la consulta asegurada del paciente con cédula 27589621','consultas'),(1376,'2024-07-02 20:17:02',28,'inserción','El usuario Enrique insertó la orden de consulta con id 000000003','recibo de consulta'),(1377,'2024-07-02 20:43:55',28,'inserción','El usuario Enrique insertó la orden de asegurada con id 000000000','recibo de asegurada'),(1378,'2024-07-02 20:55:54',28,'inserción','El usuario Enrique insertó la orden de asegurada con id 000000000','recibo de asegurada'),(1379,'2024-07-07 14:58:31',27,'inserción','El usuario Oriana insertó la consulta natural del paciente con cédula 27543567','consultas'),(1380,'2024-07-07 15:57:33',27,'inserción','El usuario Oriana insertó la orden de consulta con id 000000004','recibo de consulta'),(1381,'2024-07-08 20:21:40',27,'inserción','El usuario Oriana insertó una cita normal para el paciente Daniel Enrique Guinda Morales','citas'),(1382,'2024-07-08 20:25:53',27,'inserción','El usuario Oriana insertó la consulta natural del paciente con cédula 1-19625895','consultas'),(1383,'2024-07-08 20:27:33',27,'inserción','El usuario Oriana insertó la orden de consulta con id 000000005','recibo de consulta'),(1384,'2024-07-08 21:17:21',27,'inserción','El usuario Oriana insertó una cita asegurada para el paciente Miguel Angel Morales García','citas'),(1385,'2024-07-08 21:24:16',27,'actualización','El usuario Oriana insertó la clave de la cita id 16 del paciente Miguel Angel Morales García del día 2024-07-08','citas'),(1386,'2024-07-08 21:38:38',27,'inserción','El usuario Oriana insertó la consulta asegurada del paciente con cédula 24587563','consultas'),(1387,'2024-07-08 21:46:35',27,'inserción','El usuario Oriana insertó la orden de asegurada con id 000000004','recibo de asegurada'),(1388,'2024-07-08 21:52:02',27,'inserción','El usuario Oriana insertó la orden de consulta con id 000000006','recibo de consulta'),(1389,'2024-07-09 04:35:42',27,'inserción','El usuario Oriana insertó un nuevo antecedente médico de tipo antecedente patológico al paciente Daniel Enrique con cédula 1-19625895','antecedentes'),(1390,'2024-07-09 13:57:35',32,'inserción','El usuario Aura insertó la consulta por emergencia del paciente con cédula 27589621','consultas'),(1391,'2024-07-09 15:11:32',32,'inserción','El usuario Aura insertó una cita normal para el paciente Juan Diego Mordaza Espinosa','citas'),(1392,'2024-07-09 15:12:11',32,'inserción','El usuario Aura insertó una cita asegurada para el paciente Juan Diego Mordaza Espinosa','citas'),(1393,'2024-07-10 14:39:22',32,'inserción','El usuario Aura insertó una cita normal para el paciente Maria Carolina Guerrera Rojas','citas'),(1394,'2024-07-10 15:31:53',32,'actualización','El usuario Aura insertó la clave de la cita id 18 del paciente Juan Diego Mordaza Espinosa del día 2024-07-24','citas'),(1395,'2024-07-10 19:16:00',32,'inserción','El usuario Aura insertó un nuevo antecedente médico de tipo antecedente patológico al paciente David Miguel con cédula 27589621','antecedentes'),(1396,'2024-07-10 19:16:38',32,'eliminación','El usuario Aura eliminó el antecedente_id 5 al paciente David Miguel con cédula 27589621','antecedentes'),(1397,'2024-07-10 19:34:45',32,'eliminación','El usuario Aura removió la relación del paciente    con el seguro ','pacientes'),(1398,'2024-07-10 19:36:54',32,'eliminación','El usuario Aura removió la relación del paciente    con el seguro ','pacientes'),(1399,'2024-07-10 19:39:37',32,'eliminación','El usuario Aura removió la relación del paciente    con el seguro ','pacientes'),(1400,'2024-07-10 19:42:34',32,'eliminación','1','pacientes'),(1401,'2024-07-10 19:45:30',32,'eliminación','1','pacientes'),(1402,'2024-07-10 20:37:58',32,'actualización','Aura ha actualizado al elemento María de los Ángeles los campos tipo_paciente, tipo_relacion, titular_id, tipo_familiar, titular en el módulo pacientes','pacientes');
/*!40000 ALTER TABLE `auditoria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita`
--

DROP TABLE IF EXISTS `cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita` (
  `cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `fecha_cita` date NOT NULL,
  `hora_salida` time NOT NULL,
  `hora_entrada` time NOT NULL,
  `motivo_cita` varchar(45) NOT NULL,
  `cedula_titular` int(11) NOT NULL,
  `monto_aprobado` float NOT NULL,
  `tipo_cita` enum('1','2') NOT NULL,
  `tipo_servicio` enum('1','2') DEFAULT '1',
  `estatus_cit` enum('1','2','3','4',' 5') NOT NULL,
  PRIMARY KEY (`cita_id`),
  KEY `especialidad_id` (`especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `cita_ibfk_1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_ibfk_2` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_ibfk_3` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita`
--

LOCK TABLES `cita` WRITE;
/*!40000 ALTER TABLE `cita` DISABLE KEYS */;
INSERT INTO `cita` VALUES (7,95,11,19,'2024-06-26','08:30:00','08:00:00','Malestar estomacal desde hace una semana',23546543,0,'1','2',' 5'),(8,95,11,19,'2024-06-28','08:30:00','08:00:00','Malestar estomacal desde hace 5 días',23546543,0,'1','2',' 5'),(9,98,11,19,'2024-06-28','09:05:00','08:35:00','Acidez estomacal',27543567,0,'1','2',' 5'),(10,101,20,17,'2024-06-28','10:30:00','10:00:00','Control',27589621,0,'2','2',' 5'),(11,95,11,19,'2024-07-02','08:30:00','08:00:00','Malestar estomacal desde hace una semana',23546543,0,'1','2','4'),(12,95,11,19,'2024-07-04','08:30:00','08:00:00','Malestar estomacal desde hace 5 días',23546543,0,'1','2','2'),(13,98,11,19,'2024-07-04','09:05:00','08:35:00','Acidez estomacal',27543567,0,'1','2','4'),(15,113,12,16,'2024-07-08','10:30:00','10:00:00','Dolor de cabeza persistente',19625895,0,'1','2','4'),(16,103,13,24,'2024-07-08','08:30:00','08:00:00','Control',24587563,20,'2','2','4'),(17,104,9,11,'2024-07-10','09:30:00','09:00:00','dddd',20596321,0,'1','2','1'),(18,104,9,11,'2024-07-24','09:30:00','09:00:00','sdadsa',20596321,20,'2','2','1'),(19,95,9,11,'2024-07-26','09:30:00','09:00:00','aaaaaa',23546543,0,'1','1','1');
/*!40000 ALTER TABLE `cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_examen`
--

DROP TABLE IF EXISTS `cita_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_examen` (
  `cita_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  `precio_examen_bs` float NOT NULL,
  `precio_examen_usd` float NOT NULL,
  `cubierto_por` enum('1','2','3') NOT NULL DEFAULT '1',
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto` float NOT NULL DEFAULT 0,
  `estatus_cit` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`cita_examen_id`),
  KEY `cita_id` (`cita_id`),
  KEY `examen_id` (`examen_id`),
  CONSTRAINT `cita_examen_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_examen_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_examen`
--

LOCK TABLES `cita_examen` WRITE;
/*!40000 ALTER TABLE `cita_examen` DISABLE KEYS */;
INSERT INTO `cita_examen` VALUES (1,10,12,0,15,'1',0,0,0,'1'),(2,16,26,0,10,'2',0,0,0,'1'),(3,19,25,0,25,'1',0,0,0,'1');
/*!40000 ALTER TABLE `cita_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cita_seguro`
--

DROP TABLE IF EXISTS `cita_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cita_seguro` (
  `cita_seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `clave` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`cita_seguro_id`),
  KEY `cita_id` (`cita_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `cita_seguro_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `cita_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cita_seguro`
--

LOCK TABLES `cita_seguro` WRITE;
/*!40000 ALTER TABLE `cita_seguro` DISABLE KEYS */;
INSERT INTO `cita_seguro` VALUES (1,10,1,NULL),(2,16,4,'GHUT32'),(3,18,5,'aaaaa');
/*!40000 ALTER TABLE `cita_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `compra_insumo`
--

DROP TABLE IF EXISTS `compra_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `compra_insumo` (
  `compra_insumo_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `insumo_id` int(11) NOT NULL,
  `factura_compra_id` int(9) unsigned zerofill NOT NULL,
  `unidades` int(11) NOT NULL,
  `precio_unit_bs` float NOT NULL,
  `precio_total_bs` float NOT NULL,
  `precio_unit_usd` float NOT NULL,
  `precio_total_usd` float NOT NULL,
  PRIMARY KEY (`compra_insumo_id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `factura_compra_id` (`factura_compra_id`),
  CONSTRAINT `compra_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`insumo_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `compra_insumo_ibfk_2` FOREIGN KEY (`factura_compra_id`) REFERENCES `factura_compra` (`factura_compra_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `compra_insumo`
--

LOCK TABLES `compra_insumo` WRITE;
/*!40000 ALTER TABLE `compra_insumo` DISABLE KEYS */;
INSERT INTO `compra_insumo` VALUES (000000001,9,000000001,10,3,30,0.08,0.82),(000000002,10,000000001,10,3,30,0.08,0.82),(000000003,16,000000001,20,20,400,0.55,11),(000000004,15,000000001,20,25,500,0.69,13.74),(000000005,13,000000002,15,25,375,0.69,10.31),(000000006,12,000000003,30,15,450,0.41,12.37),(000000007,14,000000004,50,20,1000,0.55,27.49),(000000008,17,000000004,15,5,75,0.14,2.06),(000000009,18,000000004,30,50,1500,1.37,41.23),(000000010,19,000000004,5,6,30,0.16,0.82);
/*!40000 ALTER TABLE `compra_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta`
--

DROP TABLE IF EXISTS `consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta` (
  `consulta_id` int(11) NOT NULL AUTO_INCREMENT,
  `peso` float DEFAULT NULL,
  `altura` float DEFAULT NULL,
  `observaciones` varchar(255) DEFAULT NULL,
  `fecha_consulta` date NOT NULL,
  `es_emergencia` tinyint(1) NOT NULL DEFAULT 0,
  `tipo_servicio` enum('1','2') NOT NULL DEFAULT '1',
  `estatus_con` enum('1','2','3','4') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta`
--

LOCK TABLES `consulta` WRITE;
/*!40000 ALTER TABLE `consulta` DISABLE KEYS */;
INSERT INTO `consulta` VALUES (29,55,1.65,'Valores de colesterol altos','2024-06-30',0,'2','3'),(30,54,1.55,'Posible infección bacteriana','2024-06-30',0,'1','3'),(31,NULL,NULL,'El paciente tiene insuficiencia cardíaca','2024-06-30',1,'1','3'),(32,58,1.62,'indigestión común','2024-07-02',0,'2','3'),(33,75,1.68,'Chequeo normal, latidos del corazón estables, sin observaciones','2024-07-03',0,'2','4'),(34,65,1.6,'Gastritis por infección de bacteria Helicobacter pylori','2024-07-04',0,'2','3'),(35,NULL,NULL,'Cansancio visual a raíz de la televisión','2024-07-08',0,'2','3'),(36,NULL,NULL,'Todo en perfecto estado','2024-07-08',0,'2','3'),(37,1.1,1.2,'test','2024-07-07',1,'1','1');
/*!40000 ALTER TABLE `consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_cita`
--

DROP TABLE IF EXISTS `consulta_cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_cita` (
  `consulta_cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `cita_id` int(11) NOT NULL,
  `consulta_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_cita_id`),
  KEY `cita_id` (`cita_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_cita_ibfk_1` FOREIGN KEY (`cita_id`) REFERENCES `cita` (`cita_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_cita_ibfk_2` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_cita`
--

LOCK TABLES `consulta_cita` WRITE;
/*!40000 ALTER TABLE `consulta_cita` DISABLE KEYS */;
INSERT INTO `consulta_cita` VALUES (1,11,32,'1'),(3,13,34,'1'),(4,15,35,'1'),(5,16,36,'1');
/*!40000 ALTER TABLE `consulta_cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_emergencia`
--

DROP TABLE IF EXISTS `consulta_emergencia`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_emergencia` (
  `consulta_emergencia_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `cedula_beneficiado` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `clave_seguro` int(11) NOT NULL,
  `cantidad_consultas_medicas` int(11) NOT NULL DEFAULT 0,
  `consultas_medicas` float NOT NULL,
  `consultas_medicas_bs` float NOT NULL,
  `cantidad_laboratorios` int(11) NOT NULL DEFAULT 0,
  `laboratorios` float DEFAULT NULL,
  `laboratorios_bs` float NOT NULL,
  `cantidad_medicamentos` int(11) NOT NULL DEFAULT 0,
  `medicamentos` float DEFAULT NULL,
  `medicamentos_bs` float NOT NULL,
  `area_observacion` float DEFAULT NULL,
  `area_observacion_bs` float NOT NULL,
  `enfermeria` float DEFAULT NULL,
  `enfermeria_bs` float NOT NULL,
  `total_insumos` float NOT NULL,
  `total_insumos_bs` float NOT NULL,
  `total_examenes` float NOT NULL,
  `total_examenes_bs` float NOT NULL,
  `total_consulta` float NOT NULL,
  `total_consulta_bs` float NOT NULL,
  `monto_aprobado` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `autorizacion` varchar(30) DEFAULT NULL,
  PRIMARY KEY (`consulta_emergencia_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `consulta_emergencia_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_emergencia_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_emergencia_ibfk_3` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_emergencia`
--

LOCK TABLES `consulta_emergencia` WRITE;
/*!40000 ALTER TABLE `consulta_emergencia` DISABLE KEYS */;
INSERT INTO `consulta_emergencia` VALUES (1,31,106,18451236,1,0,0,25,0,0,0,0,0,2,0,15,0,12,0,4,0,25,0,83,0,83,0,0,'GHU7435'),(2,37,101,27589621,1,0,0,30,0,0,0,0,0,0,0,10,0,10,0,0,0,25,0,75,0,60,0,0,'75');
/*!40000 ALTER TABLE `consulta_emergencia` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_examen`
--

DROP TABLE IF EXISTS `consulta_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_examen` (
  `consulta_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `examen_id` int(11) NOT NULL,
  `precio_examen_bs` float NOT NULL,
  `precio_examen_usd` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `cubierto_por` enum('1','2','3') NOT NULL DEFAULT '1',
  `monto_cubierto_bs` float NOT NULL DEFAULT 0,
  `monto_cubierto_usd` float NOT NULL DEFAULT 0,
  `monto_cubierto` float NOT NULL DEFAULT 0,
  PRIMARY KEY (`consulta_examen_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `examen_id` (`examen_id`),
  CONSTRAINT `consulta_examen_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_examen_ibfk_2` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_examen`
--

LOCK TABLES `consulta_examen` WRITE;
/*!40000 ALTER TABLE `consulta_examen` DISABLE KEYS */;
INSERT INTO `consulta_examen` VALUES (1,30,14,546.69,15,'1','1',0,0,0),(2,31,13,546.69,25,'1','1',0,0,0),(3,37,13,0,25,'1','1',0,0,0);
/*!40000 ALTER TABLE `consulta_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_indicaciones`
--

DROP TABLE IF EXISTS `consulta_indicaciones`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_indicaciones` (
  `consulta_indicaciones_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `descripcion` text NOT NULL,
  PRIMARY KEY (`consulta_indicaciones_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_indicaciones_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_indicaciones`
--

LOCK TABLES `consulta_indicaciones` WRITE;
/*!40000 ALTER TABLE `consulta_indicaciones` DISABLE KEYS */;
INSERT INTO `consulta_indicaciones` VALUES (1,29,'Disminuir el consumo de azúcares, harinas y grasas'),(2,30,'Guardar reposo durante 48 horas'),(3,35,'No sobrepasar las 4 horas diarias frente al televisor, procurar tener una distancia de al menos 1 metro del televisor');
/*!40000 ALTER TABLE `consulta_indicaciones` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_insumo`
--

DROP TABLE IF EXISTS `consulta_insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_insumo` (
  `consulta_insumo_id` int(11) NOT NULL AUTO_INCREMENT,
  `insumo_id` int(11) NOT NULL,
  `consulta_id` int(11) NOT NULL,
  `cantidad` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `precio_insumo_bs` float NOT NULL,
  `precio_insumo_usd` float NOT NULL,
  PRIMARY KEY (`consulta_insumo_id`),
  KEY `insumo_id` (`insumo_id`),
  KEY `consulta_id` (`consulta_id`),
  CONSTRAINT `consulta_insumo_ibfk_1` FOREIGN KEY (`insumo_id`) REFERENCES `insumo` (`insumo_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_insumo_ibfk_2` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_insumo`
--

LOCK TABLES `consulta_insumo` WRITE;
/*!40000 ALTER TABLE `consulta_insumo` DISABLE KEYS */;
INSERT INTO `consulta_insumo` VALUES (1,17,31,2,'1',0,1),(2,14,31,4,'1',0,1);
/*!40000 ALTER TABLE `consulta_insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_recipe`
--

DROP TABLE IF EXISTS `consulta_recipe`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_recipe` (
  `consulta_recipe_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `medicamento_id` int(11) NOT NULL,
  `uso` text NOT NULL,
  PRIMARY KEY (`consulta_recipe_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `medicamento_id` (`medicamento_id`),
  CONSTRAINT `consulta_recipe_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_recipe_ibfk_2` FOREIGN KEY (`medicamento_id`) REFERENCES `medicamento` (`medicamento_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_recipe`
--

LOCK TABLES `consulta_recipe` WRITE;
/*!40000 ALTER TABLE `consulta_recipe` DISABLE KEYS */;
INSERT INTO `consulta_recipe` VALUES (1,30,18,'1 tableta diaria por 30 días'),(2,32,15,'1 tableta cada 8 horas por 5 días'),(3,34,15,'1 capsula diaria junto al desayuno'),(4,34,16,'1 capsula diaria después del omeprazol'),(5,35,24,'una pastilla cada 8 horas hasta que desaparezca el dolor');
/*!40000 ALTER TABLE `consulta_recipe` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_referidos`
--

DROP TABLE IF EXISTS `consulta_referidos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_referidos` (
  `consulta_referidos_id` int(9) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_referidos_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `consulta_referidos_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_referidos_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_referidos`
--

LOCK TABLES `consulta_referidos` WRITE;
/*!40000 ALTER TABLE `consulta_referidos` DISABLE KEYS */;
INSERT INTO `consulta_referidos` VALUES (1,31,17,'1');
/*!40000 ALTER TABLE `consulta_referidos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_seguro`
--

DROP TABLE IF EXISTS `consulta_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_seguro` (
  `consulta_seguro_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `tipo_servicio` varchar(50) NOT NULL,
  `fecha_ocurrencia` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `monto_consulta_usd` float NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  `monto_consulta_bs` float NOT NULL,
  `cobertura_seguro` float NOT NULL,
  PRIMARY KEY (`consulta_seguro_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `consulta_seguro_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_seguro`
--

LOCK TABLES `consulta_seguro` WRITE;
/*!40000 ALTER TABLE `consulta_seguro` DISABLE KEYS */;
INSERT INTO `consulta_seguro` VALUES (000000001,31,1,'','2024-07-02 03:37:22',83,'1',0,83),(000000004,36,4,'','2024-07-09 03:46:30',25,'1',0,20);
/*!40000 ALTER TABLE `consulta_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `consulta_sin_cita`
--

DROP TABLE IF EXISTS `consulta_sin_cita`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `consulta_sin_cita` (
  `consulta_sin_cita_id` int(11) NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `medico_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `estatus_con` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`consulta_sin_cita_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `especialidad_id` (`especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `consulta_sin_cita_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_3` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `consulta_sin_cita_ibfk_4` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `consulta_sin_cita`
--

LOCK TABLES `consulta_sin_cita` WRITE;
/*!40000 ALTER TABLE `consulta_sin_cita` DISABLE KEYS */;
INSERT INTO `consulta_sin_cita` VALUES (2,29,26,10,114,'1'),(3,30,11,18,99,'1');
/*!40000 ALTER TABLE `consulta_sin_cita` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `empresa`
--

DROP TABLE IF EXISTS `empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `empresa` (
  `empresa_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `rif` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `estatus_emp` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`empresa_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `empresa`
--

LOCK TABLES `empresa` WRITE;
/*!40000 ALTER TABLE `empresa` DISABLE KEYS */;
INSERT INTO `empresa` VALUES (2,'Vasos Venezolanos C.A','J-000127689','Avenida Mérida, Maracay','1'),(3,'Manufacturas de Papel C.A','J-000235309','Av. Aragua, Maracay','1'),(4,'Inversiones Selva C.A','J-000473501','Maracay, avenida Mérida','1'),(5,'Panaven C.A','J-500296681','Calle Falcon, Maracay','1'),(6,'Grupo Farma','J-000133930','Av. Intersan, Zona Industrial La Hamaca, Mara','1');
/*!40000 ALTER TABLE `empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `especialidad`
--

DROP TABLE IF EXISTS `especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `especialidad` (
  `especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `estatus_esp` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`especialidad_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `especialidad`
--

LOCK TABLES `especialidad` WRITE;
/*!40000 ALTER TABLE `especialidad` DISABLE KEYS */;
INSERT INTO `especialidad` VALUES (11,'Traumatología','1'),(12,'Psicología','1'),(13,'Pediatría','1'),(14,'Oncología','1'),(15,'Otorrinolaringología','1'),(16,'Oftamología','1'),(17,'Cardiología','1'),(18,'Dermatología','1'),(19,'Gastroenterología','1'),(20,'Endocrinología','1'),(21,'Ortopedia','1'),(22,'Psiquiatría','1'),(23,'Fisioterapía','1'),(24,'Ginecología','1'),(25,'Acupuntura','1'),(26,'Medicina General','1');
/*!40000 ALTER TABLE `especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examen`
--

DROP TABLE IF EXISTS `examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examen` (
  `examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `precio_examen` int(11) DEFAULT NULL,
  `tipo` enum('1','2','3') NOT NULL,
  `estatus_exa` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`examen_id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examen`
--

LOCK TABLES `examen` WRITE;
/*!40000 ALTER TABLE `examen` DISABLE KEYS */;
INSERT INTO `examen` VALUES (12,'Ecocardiograma',25,'1','1'),(13,'Resonancia magnética del corazón',25,'1','1'),(14,'Artrocentesis',15,'3','1'),(15,'biopsia cutánea',12,'3','1'),(16,'Prick Test',20,'3','1'),(17,'Audiometría',15,'3','1'),(18,'Timpanometría',15,'3','1'),(19,'Refracción',10,'3','1'),(20,'Paquimetría',15,'3','1'),(21,'Ultrasonidos del Abdomen',30,'1','1'),(22,'Escaneo de tiroides',23,'1','1'),(23,'HbA1c azúcar en sangre',15,'3','1'),(24,'Endoscopia gastrointestinal',20,'3','1'),(25,'Colonoscopia',25,'3','1'),(26,'Citología',10,'3','1'),(27,'Ecografía vaginal',15,'3','1'),(28,'Mamografía',15,'1','1');
/*!40000 ALTER TABLE `examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `examen_especialidad`
--

DROP TABLE IF EXISTS `examen_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `examen_especialidad` (
  `examen_especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `examen_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `estatus_exa` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`examen_especialidad_id`),
  KEY `examen_id` (`examen_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `examen_especialidad_ibfk_1` FOREIGN KEY (`examen_id`) REFERENCES `examen` (`examen_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `examen_especialidad_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `examen_especialidad`
--

LOCK TABLES `examen_especialidad` WRITE;
/*!40000 ALTER TABLE `examen_especialidad` DISABLE KEYS */;
INSERT INTO `examen_especialidad` VALUES (13,12,17,'1'),(14,13,17,'1'),(15,14,11,'1'),(16,15,18,'1'),(17,16,18,'1'),(18,17,15,'1'),(19,18,15,'1'),(20,19,16,'1'),(21,20,15,'1'),(22,21,20,'1'),(23,22,20,'1'),(24,23,20,'1'),(25,24,19,'1'),(26,25,11,'1'),(27,26,24,'1'),(28,27,24,'1'),(29,28,24,'1');
/*!40000 ALTER TABLE `examen_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_compra`
--

DROP TABLE IF EXISTS `factura_compra`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_compra` (
  `factura_compra_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `proveedor_id` int(11) NOT NULL,
  `fecha_compra` datetime NOT NULL,
  `total_productos` int(11) NOT NULL,
  `monto_con_iva` float NOT NULL,
  `monto_sin_iva` float NOT NULL,
  `monto_usd` float NOT NULL,
  `excento` float DEFAULT NULL,
  `motivo_cancelacion` text DEFAULT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_compra_id`),
  KEY `proveedor_id` (`proveedor_id`),
  CONSTRAINT `factura_compra_ibfk_1` FOREIGN KEY (`proveedor_id`) REFERENCES `proveedor` (`proveedor_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_compra`
--

LOCK TABLES `factura_compra` WRITE;
/*!40000 ALTER TABLE `factura_compra` DISABLE KEYS */;
INSERT INTO `factura_compra` VALUES (000000001,6,'2024-06-20 00:00:00',60,960,960,26.39,0,NULL,'1'),(000000002,7,'2024-06-24 00:00:00',15,375,375,10.31,0,NULL,'1'),(000000003,7,'2024-06-21 00:00:00',30,450,450,12.37,0,NULL,'1'),(000000004,5,'2024-06-21 00:00:00',100,2605,2605,71.61,0,NULL,'1');
/*!40000 ALTER TABLE `factura_compra` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_consulta`
--

DROP TABLE IF EXISTS `factura_consulta`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_consulta` (
  `factura_consulta_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `consulta_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `metodo_pago` varchar(20) NOT NULL,
  `monto_consulta_bs` float NOT NULL,
  `monto_consulta_usd` float NOT NULL,
  `tipo_consulta` enum('1','2') NOT NULL,
  `estatus_fac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_consulta_id`),
  KEY `consulta_id` (`consulta_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `factura_consulta_ibfk_1` FOREIGN KEY (`consulta_id`) REFERENCES `consulta` (`consulta_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factura_consulta_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_consulta`
--

LOCK TABLES `factura_consulta` WRITE;
/*!40000 ALTER TABLE `factura_consulta` DISABLE KEYS */;
INSERT INTO `factura_consulta` VALUES (00000001,29,114,'efectivo',546.75,15,'1','1'),(00000002,30,99,'debito',0,0,'1','1'),(00000003,32,95,'efectivo',729.1,20,'1','1'),(00000004,34,98,'debito',729.5,20,'1','1'),(00000005,35,113,'efectivo',547.335,15,'1','1'),(00000006,36,103,'efectivo',547.335,15,'1','1');
/*!40000 ALTER TABLE `factura_consulta` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_medico`
--

DROP TABLE IF EXISTS `factura_medico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_medico` (
  `factura_medico_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `acumulado_seguro_total` float DEFAULT NULL,
  `acumulado_consulta_total` float DEFAULT NULL,
  `sumatoria_consultas_aseguradas` float NOT NULL,
  `sumatoria_consultas_naturales` float NOT NULL,
  `acumulado_medico` float NOT NULL,
  `pago_total` float DEFAULT NULL,
  `factura_medico` float NOT NULL,
  `fecha_pago` date DEFAULT NULL,
  `fecha_emision` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `pacientes_seguro` int(11) DEFAULT NULL,
  `pacientes_consulta` int(11) DEFAULT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_medico_id`),
  KEY `medico_id` (`medico_id`),
  CONSTRAINT `factura_medico_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_medico`
--

LOCK TABLES `factura_medico` WRITE;
/*!40000 ALTER TABLE `factura_medico` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_medico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_mensajeria`
--

DROP TABLE IF EXISTS `factura_mensajeria`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_mensajeria` (
  `factura_mensajeria_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `fecha_mensajeria` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `seguro_id` int(11) NOT NULL,
  `total_mensajeria_bs` float NOT NULL,
  `total_mensajeria_usd` float NOT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_mensajeria_id`),
  KEY `fk_mensajeria_seguro` (`seguro_id`),
  CONSTRAINT `fk_mensajeria_seguro` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_mensajeria`
--

LOCK TABLES `factura_mensajeria` WRITE;
/*!40000 ALTER TABLE `factura_mensajeria` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_mensajeria` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_mensajeria_consultas`
--

DROP TABLE IF EXISTS `factura_mensajeria_consultas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_mensajeria_consultas` (
  `factura_mensajeria_consultas_id` int(9) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `factura_mensajeria_id` int(9) unsigned zerofill NOT NULL,
  `consulta_seguro_id` int(9) unsigned zerofill NOT NULL,
  `fecha_mensajeria_consultas` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `estatus_fac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_mensajeria_consultas_id`),
  KEY `fk_mensajeria_consultas` (`consulta_seguro_id`),
  KEY `factura_mensajeria_id` (`factura_mensajeria_id`),
  CONSTRAINT `factura_mensajeria_consultas_ibfk_1` FOREIGN KEY (`consulta_seguro_id`) REFERENCES `consulta_seguro` (`consulta_seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `factura_mensajeria_consultas_ibfk_2` FOREIGN KEY (`factura_mensajeria_id`) REFERENCES `factura_mensajeria` (`factura_mensajeria_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_mensajeria_consultas`
--

LOCK TABLES `factura_mensajeria_consultas` WRITE;
/*!40000 ALTER TABLE `factura_mensajeria_consultas` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_mensajeria_consultas` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `factura_seguro`
--

DROP TABLE IF EXISTS `factura_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `factura_seguro` (
  `factura_seguro_id` int(8) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `seguro_id` int(11) NOT NULL,
  `nro_control` int(11) DEFAULT NULL,
  `mes` varchar(10) NOT NULL,
  `fecha_ocurrencia` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fecha_vencimiento` date NOT NULL,
  `monto_usd` float NOT NULL,
  `monto_bs` float NOT NULL,
  `estatus_fac` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`factura_seguro_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `factura_seguro_ibfk_1` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `factura_seguro`
--

LOCK TABLES `factura_seguro` WRITE;
/*!40000 ALTER TABLE `factura_seguro` DISABLE KEYS */;
/*!40000 ALTER TABLE `factura_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `global`
--

DROP TABLE IF EXISTS `global`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `global` (
  `global_id` int(11) NOT NULL AUTO_INCREMENT,
  `key` text NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`global_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `global`
--

LOCK TABLES `global` WRITE;
/*!40000 ALTER TABLE `global` DISABLE KEYS */;
INSERT INTO `global` VALUES (1,'porcentaje_medico','35'),(2,'cambio_divisa','36.51'),(3,'porcentaje_insumo','5');
/*!40000 ALTER TABLE `global` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `horario`
--

DROP TABLE IF EXISTS `horario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `horario` (
  `horario_id` int(11) NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `dias_semana` enum('lunes','martes','miercoles','jueves','viernes','sabado') NOT NULL,
  `hora_salida` time NOT NULL,
  `hora_entrada` time NOT NULL,
  `estatus_hor` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`horario_id`),
  KEY `medico_id` (`medico_id`),
  CONSTRAINT `horario_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `horario`
--

LOCK TABLES `horario` WRITE;
/*!40000 ALTER TABLE `horario` DISABLE KEYS */;
INSERT INTO `horario` VALUES (10,9,'lunes','13:00:00','08:00:00','1'),(11,9,'martes','13:00:00','08:00:00','1'),(12,9,'viernes','14:00:00','09:00:00','1'),(13,10,'martes','15:00:00','09:00:00','1'),(14,10,'miercoles','15:00:00','09:00:00','1'),(15,10,'jueves','16:00:00','10:00:00','1'),(16,11,'jueves','12:00:00','08:00:00','1'),(17,11,'viernes','12:00:00','08:00:00','1'),(18,11,'sabado','13:00:00','08:00:00','1'),(19,12,'lunes','15:00:00','10:00:00','1'),(20,12,'martes','16:00:00','10:00:00','1'),(21,12,'viernes','16:00:00','08:00:00','1'),(22,13,'lunes','16:00:00','08:00:00','1'),(23,13,'martes','16:00:00','09:00:00','1'),(24,13,'viernes','16:00:00','08:00:00','1'),(25,13,'sabado','12:00:00','09:00:00','1'),(26,14,'jueves','12:00:00','08:00:00','1'),(27,14,'viernes','13:00:00','09:00:00','1'),(28,14,'sabado','15:00:00','08:00:00','1'),(29,15,'jueves','15:00:00','09:00:00','1'),(30,15,'viernes','16:00:00','09:00:00','1'),(31,15,'sabado','17:00:00','09:00:00','1'),(32,16,'lunes','16:00:00','10:00:00','1'),(33,16,'miercoles','15:00:00','09:00:00','1'),(34,17,'jueves','14:00:00','08:00:00','1'),(35,17,'viernes','14:00:00','08:00:00','1'),(36,17,'sabado','15:00:00','09:00:00','1'),(37,18,'lunes','16:00:00','13:00:00','1'),(38,18,'viernes','16:00:00','09:00:00','1'),(39,18,'sabado','12:00:00','08:00:00','1'),(40,19,'lunes','12:00:00','09:00:00','1'),(41,19,'miercoles','17:00:00','10:00:00','1'),(42,19,'viernes','14:00:00','09:00:00','1'),(43,19,'sabado','15:00:00','10:00:00','1'),(44,20,'martes','13:00:00','09:00:00','1'),(45,20,'miercoles','13:00:00','09:00:00','1'),(46,20,'viernes','15:00:00','10:00:00','1'),(47,20,'sabado','15:00:00','10:00:00','1'),(48,19,'jueves','11:00:00','10:00:00','1');
/*!40000 ALTER TABLE `horario` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `insumo`
--

DROP TABLE IF EXISTS `insumo`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `insumo` (
  `insumo_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL DEFAULT '0',
  `cantidad_min` float NOT NULL,
  `cantidad_unidad` float NOT NULL DEFAULT 0,
  `capacidad_unidad` float NOT NULL,
  `cantidad_capacidad` float NOT NULL,
  `precio` float NOT NULL DEFAULT 0,
  `tipo_medida` enum('1','2','3','4') NOT NULL,
  `es_cobrado` enum('0','1') NOT NULL,
  `tipo_insumo` enum('1','2') DEFAULT '1',
  `estatus_ins` enum('1','2','3') NOT NULL DEFAULT '1',
  PRIMARY KEY (`insumo_id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `insumo`
--

LOCK TABLES `insumo` WRITE;
/*!40000 ALTER TABLE `insumo` DISABLE KEYS */;
INSERT INTO `insumo` VALUES (9,'Alcohol Etílico',5000,10,2000,20000,0.08,'2','1','1','1'),(10,'Alcohol Isopropílico',5000,10,2000,20000,0,'2','0','1','1'),(11,'alcohol',2000,0,2000,0,0,'2','0','1','2'),(12,'Venda Elástica Adhesiva',5000,30,5000,150000,0.43,'1','1','1','1'),(13,'Solución antiséptica',2000,15,1000,15000,0.5,'2','1','1','1'),(14,'Jeringas desechables',20,49.96,100,4996,1,'3','1','1','1'),(15,'Apósitos estériles',20,20,100,2000,0.2,'3','1','1','1'),(16,'Gasas estériles',10,20,50,1000,0.58,'3','1','1','1'),(17,'Aspirina',12,14.9333,30,448,1,'3','1','2','1'),(18,'Epinefrina',8,30,1,30,1.44,'4','1','2','1'),(19,'Diazepam pastillas',12,5,20,100,1.2,'3','1','2','1'),(20,'Diazepam ampollas',6,0,1,0,1.5,'4','1','2','1'),(21,'Amiodarona',20,0,10,0,0.9,'3','1','2','2');
/*!40000 ALTER TABLE `insumo` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medicamento`
--

DROP TABLE IF EXISTS `medicamento`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medicamento` (
  `medicamento_id` int(11) NOT NULL AUTO_INCREMENT,
  `especialidad_id` int(11) NOT NULL,
  `nombre_medicamento` varchar(45) NOT NULL,
  `tipo_medicamento` enum('1','2','3','4','5','6') DEFAULT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medicamento_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `medicamento_ibfk_1` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medicamento`
--

LOCK TABLES `medicamento` WRITE;
/*!40000 ALTER TABLE `medicamento` DISABLE KEYS */;
INSERT INTO `medicamento` VALUES (5,26,'Ibuprofeno 400 mg','1','1'),(6,26,'Acetaminofen 500 mg','1','1'),(7,15,'Montelukast 15 mg','1','1'),(8,17,'Losartán Potásico 100 mg','1','1'),(9,17,'Metolazona 2,5 mg','1','1'),(10,11,'Prednisona','2','1'),(11,11,'Metocarbamol 750 mg','1','1'),(12,14,'Altretamina','2','1'),(13,14,'Busulfan','3','1'),(14,14,'Carmustina 100 mg','3','1'),(15,19,'Omeprazol 20 mg','1','1'),(16,19,'Ranitidina 50 mg','3','1'),(17,19,'Enterogermina','4','1'),(18,11,'Artrovit','1','1'),(19,20,'Levotiroxina Sódica 50 mg','1','1'),(20,19,'Amlodipina 10 mg','1','1'),(21,24,'Aciclovir','1','1'),(22,22,'Sertralina 50 mg','1','1'),(23,15,'Desloratadina 40 mg','1','1'),(24,26,'ketroprofeno 100 mg','1','1'),(25,20,'Metimazol 100 mg','1','1'),(26,15,'Fanasal','5','1'),(27,15,'Airfren 15 ml','5','1'),(28,15,'Fisiolin','5','1'),(29,24,'Clotrimazol','6','1'),(30,18,'Dermosupril','6','1'),(31,18,'Baycuten','6','1'),(32,18,'Dermazol 0,05','6','1'),(33,16,'Dextran','5','1'),(34,18,'Oftagen','1','1');
/*!40000 ALTER TABLE `medicamento` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico`
--

DROP TABLE IF EXISTS `medico`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medico` (
  `medico_id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` int(11) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) NOT NULL,
  `acumulado` int(11) NOT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medico_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico`
--

LOCK TABLES `medico` WRITE;
/*!40000 ALTER TABLE `medico` DISABLE KEYS */;
INSERT INTO `medico` VALUES (9,12859456,'Juan Gabriel','Pérez Sánchez','04124548962','Barrio 23 de Enero, Calle Unión',0,'1'),(10,18596235,'Rosa María','Peñalver Sujosa','04144589623','Barrio el Milagro',0,'1'),(11,21589623,'Juan Francisco','Ledezma Perez','04268495623','Barrio Bolívar Sur, Calle España',0,'1'),(12,18474514,'María del Carmen','Torrealba oil','04125456454','Turmero, Residencias Campo Alegre',0,'1'),(13,21548795,'Luis Fernando','Rojas Mejías','04127878784','Turmero, Urb. La Mantuana',0,'1'),(14,19584623,'Rafael Antonio','Vergara Sánchez','04245484846','Barrio Los Olivos Nuevos, calle Lozada',0,'1'),(15,25847941,'Manuel Antonio','Sorias Sebian','04124874569','Turmero, Urb. Matacaballos',0,'1'),(16,12359855,'Juan Fernando','Lisandro Pérez','04244569878','Barrio Campo Alegre, Séctor 13 de Enero',0,'1'),(17,17845962,'Antonio Miguel','Ledezma Gonzalez','04125848465','Av. Bérmudez, Urb el Centro',0,'1'),(18,12589641,'Luis Alejandro','Morales Rojas','04122615954','Barrio Andrés Eloy Blanco, calle Comercio',0,'1'),(19,15432432,'Juana Angelina','Gutiérrez Candela','04122345432','Cagua, Urb. Santa Rosalía',0,'1'),(20,21345444,'María de los Angeles','Peraza Olivares','04142341212','Barrio 23 de enero, Calle Unión',0,'1');
/*!40000 ALTER TABLE `medico` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `medico_especialidad`
--

DROP TABLE IF EXISTS `medico_especialidad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `medico_especialidad` (
  `medico_especialidad_id` int(11) NOT NULL AUTO_INCREMENT,
  `medico_id` int(11) NOT NULL,
  `especialidad_id` int(11) NOT NULL,
  `costo_especialidad` int(11) NOT NULL,
  `estatus_med` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`medico_especialidad_id`),
  KEY `medico_id` (`medico_id`),
  KEY `especialidad_id` (`especialidad_id`),
  CONSTRAINT `medico_especialidad_ibfk_1` FOREIGN KEY (`medico_id`) REFERENCES `medico` (`medico_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `medico_especialidad_ibfk_2` FOREIGN KEY (`especialidad_id`) REFERENCES `especialidad` (`especialidad_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `medico_especialidad`
--

LOCK TABLES `medico_especialidad` WRITE;
/*!40000 ALTER TABLE `medico_especialidad` DISABLE KEYS */;
INSERT INTO `medico_especialidad` VALUES (9,9,11,15,'1'),(10,10,26,15,'1'),(11,10,13,18,'1'),(12,11,19,20,'1'),(13,11,20,25,'1'),(14,12,16,15,'1'),(15,13,24,25,'1'),(16,13,26,12,'1'),(17,14,15,25,'1'),(18,15,25,20,'1'),(19,15,23,15,'1'),(20,16,12,25,'1'),(21,16,22,30,'1'),(22,17,14,28,'1'),(23,17,26,15,'1'),(24,18,21,30,'1'),(25,18,11,25,'1'),(26,19,18,12,'1'),(27,20,17,30,'1');
/*!40000 ALTER TABLE `medico_especialidad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente`
--

DROP TABLE IF EXISTS `paciente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente` (
  `paciente_id` int(11) NOT NULL AUTO_INCREMENT,
  `cedula` varchar(20) NOT NULL,
  `nombre` varchar(45) NOT NULL,
  `apellidos` varchar(45) NOT NULL,
  `fecha_nacimiento` date NOT NULL,
  `edad` int(11) NOT NULL,
  `telefono` varchar(45) DEFAULT NULL,
  `direccion` varchar(45) NOT NULL,
  `tipo_paciente` enum('1','2','3','4') NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_id`)
) ENGINE=InnoDB AUTO_INCREMENT=117 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente`
--

LOCK TABLES `paciente` WRITE;
/*!40000 ALTER TABLE `paciente` DISABLE KEYS */;
INSERT INTO `paciente` VALUES (95,'23546543','Maria Carolina','Guerrera Rojas','1995-08-10',28,'04123435678','Campo Bolívar Sur','1','1'),(96,'18435444','Juan David','Morales Ojeda','1985-02-17',39,'04125443212','Urb. El centro','1','1'),(97,'19254321','Luis Miguel','Carrero Gonzalez','1990-08-23',33,'04126758954','Barrio 23 de Enero, Calle Infancia','1','1'),(98,'27543567','Miguelangel','Flores Carrillo','2000-01-11',24,'04122498565','Caña de Azúcar, sector 4','1','1'),(99,'28475431','Luz del Carmen','Rosa Colmenares','2001-03-15',23,'04164356767','Barrio La Coromoto, calle Mérida','1','1'),(100,'14564321','Juan Carlos','Blanco Meza','1980-10-01',43,'04245675321','Barrio San Rafael','1','1'),(101,'27589621','David Miguel','Mijares Sanchez','2000-05-10',24,'04127849659','Barrio 23 de enero, calle Urdaneta','3','1'),(102,'21963589','Luis Angel','Lopez Aveledo','1993-01-10',31,'04127485124','Barrio Bolívar Sur, Calle Esperanza','3','1'),(103,'24587563','Rosalía Ana','Morales García','1995-05-13',29,'04121245121','Barrio Los Olivos Nuevos','3','1'),(104,'20596321','Juan Diego','Mordaza Espinosa','1990-11-13',33,'04147849658','Campo Alegre, calle el Saman','3','1'),(105,'16548987','Ana Carmen','Perez Riñonez','1980-10-13',43,'04267896542','Campo Alegre, sector 13 de Enero','3','1'),(106,'18451236','Angela Nora','Jiménez Beltrán','1982-12-10',41,'04247849658','Brisas del Lago, callejón tuyare','3','1'),(107,'24874123','Luisa Daniela','Mejias Blanco','2000-08-15',23,'04148964752','Campo Alegre, calle Anacoco','3','1'),(108,'16487965','Wendy Carmiña','López Gutierrez','1980-09-11',43,'04127849587','Urb. Las Acacias, vereda 64','3','1'),(109,'28569321','Sarai Angela','Mendez Rosales','2001-10-12',22,'04147489624','Barrio San José, Avenida 2','4','1'),(110,'29478563','María de los Ángeles','Colmeres Pérez','2002-02-15',22,'04127489652','Urb. Las Acacias, vereda 5','4','1'),(111,'27452318','Ana Angelica','Alvarez Morales','2000-10-09',23,'04247894578','Urb. La Fundación, calle Humboldt','4','1'),(112,'19625895','Rosa Angelica','Morales Jimenez','1990-06-15',34,'04167489568','Urb. Madre María','2','1'),(113,'1-19625895','Daniel Enrique','Guinda Morales','2015-09-15',8,'04167489568','Urb. Madre María','4','1'),(114,'15984263','Olga María','Coromoto Mendez','1980-09-13',43,'04247849636','Barrio 12 de Febrero, calle Pérez Ramos','2','1'),(115,'1-15984263','Juan Diego','Cristiano Coromoto','2018-07-18',5,'04247849636','Barrio 12 de Febrero, calle Pérez Ramos','4','1'),(116,'2-15984263','Diana Miranda','Castellano Colmenares','2015-04-15',9,'04247849636','Barrio 12 de Febrero, calle Pérez Ramos','4','1');
/*!40000 ALTER TABLE `paciente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente_beneficiado`
--

DROP TABLE IF EXISTS `paciente_beneficiado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente_beneficiado` (
  `paciente_beneficiado_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_beneficiado_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `paciente_beneficiado_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente_beneficiado`
--

LOCK TABLES `paciente_beneficiado` WRITE;
/*!40000 ALTER TABLE `paciente_beneficiado` DISABLE KEYS */;
INSERT INTO `paciente_beneficiado` VALUES (12,109,'1'),(13,110,'1'),(14,111,'2'),(15,113,'1'),(16,115,'1'),(17,116,'1');
/*!40000 ALTER TABLE `paciente_beneficiado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paciente_seguro`
--

DROP TABLE IF EXISTS `paciente_seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `paciente_seguro` (
  `paciente_seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `empresa_id` int(11) NOT NULL,
  `tipo_seguro` enum('1','2') NOT NULL,
  `cobertura_general` float NOT NULL,
  `fecha_contra` date NOT NULL,
  `saldo_disponible` float NOT NULL,
  `estatus_pac` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`paciente_seguro_id`),
  KEY `paciente_id` (`paciente_id`),
  KEY `seguro_id` (`seguro_id`),
  KEY `empresa_id` (`empresa_id`),
  CONSTRAINT `paciente_seguro_ibfk_1` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paciente_seguro_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `paciente_seguro_ibfk_3` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`empresa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paciente_seguro`
--

LOCK TABLES `paciente_seguro` WRITE;
/*!40000 ALTER TABLE `paciente_seguro` DISABLE KEYS */;
INSERT INTO `paciente_seguro` VALUES (1,101,1,2,'1',0,'2012-05-12',0,'1'),(2,102,2,5,'1',0,'2011-02-10',0,'2'),(3,103,4,6,'1',0,'2008-05-10',0,'1'),(4,104,5,3,'1',0,'2020-10-01',0,'1'),(5,105,1,2,'1',0,'2021-10-10',0,'1'),(6,106,1,2,'1',0,'2021-10-10',0,'1'),(7,107,1,3,'1',0,'2022-07-16',0,'1'),(8,108,1,4,'1',0,'2023-03-05',0,'1');
/*!40000 ALTER TABLE `paciente_seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pregunta_seguridad`
--

DROP TABLE IF EXISTS `pregunta_seguridad`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pregunta_seguridad` (
  `pregunta_id` int(11) NOT NULL AUTO_INCREMENT,
  `usuario_id` int(11) NOT NULL,
  `pregunta` varchar(100) NOT NULL,
  `respuesta` varchar(100) NOT NULL,
  `estatus_pre` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`pregunta_id`),
  KEY `usuario_id` (`usuario_id`),
  CONSTRAINT `pregunta_seguridad_ibfk_1` FOREIGN KEY (`usuario_id`) REFERENCES `usuario` (`usuario_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=52 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pregunta_seguridad`
--

LOCK TABLES `pregunta_seguridad` WRITE;
/*!40000 ALTER TABLE `pregunta_seguridad` DISABLE KEYS */;
INSERT INTO `pregunta_seguridad` VALUES (31,27,'1','amarillo','1'),(32,27,'2','rocky','1'),(33,27,'3','perez','1'),(34,28,'1','rojo','1'),(35,28,'5','jugar','1'),(36,28,'8','limon','1'),(37,29,'1','amarillo','1'),(38,29,'2','rocky','1'),(39,29,'3','perez','1'),(40,30,'1','amarillo','1'),(41,30,'2','rocky','1'),(42,30,'5','dibujar','1'),(43,31,'1','amarillo','1'),(44,31,'3','perez','1'),(45,31,'4','guayaba','1'),(46,32,'1','amarillo','1'),(47,32,'3','perez','1'),(48,32,'8','limon','1');
/*!40000 ALTER TABLE `pregunta_seguridad` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proveedor`
--

DROP TABLE IF EXISTS `proveedor`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `proveedor` (
  `proveedor_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `ubicacion` varchar(255) NOT NULL,
  `estatus_pro` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`proveedor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proveedor`
--

LOCK TABLES `proveedor` WRITE;
/*!40000 ALTER TABLE `proveedor` DISABLE KEYS */;
INSERT INTO `proveedor` VALUES (5,'Grupo Farma C.A','Complejo Industrial La Hamaca','1'),(6,'Suplementos Médicos C.A','Caracas','1'),(7,'Insumos Maracay C.A','Maracay, San Vicente','1');
/*!40000 ALTER TABLE `proveedor` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro`
--

DROP TABLE IF EXISTS `seguro`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro` (
  `seguro_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(45) NOT NULL,
  `rif` varchar(45) NOT NULL,
  `direccion` varchar(45) NOT NULL,
  `telefono` varchar(13) NOT NULL,
  `porcentaje` int(11) NOT NULL,
  `costo_consulta` int(11) NOT NULL,
  `maximo_dias` int(11) NOT NULL DEFAULT 15,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro`
--

LOCK TABLES `seguro` WRITE;
/*!40000 ALTER TABLE `seguro` DISABLE KEYS */;
INSERT INTO `seguro` VALUES (1,'Seguros La Previsora','J-000213763','Caracas','04124002701',20,28,21,'1'),(2,'Seguros Horizonte S.A','G-200087013','Caracas','04249554823',25,20,15,'1'),(3,'Banesco Seguros','J-300831183','Caracas, El Rosal','04123214421',20,15,21,'1'),(4,'Seguros Venezuela','J-000340366','Av. Francisco de Miranda, Caracas','04127829832',18,18,15,'1'),(5,'Seguros Pirámides','J-001064745','Urbanización la Floresta, Maracay','04247747264',15,25,21,'1'),(6,'Seguros Qualitas','J-306684506','Av. Francisco de Miranda','04125235235',15,16,15,'1');
/*!40000 ALTER TABLE `seguro` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro_empresa`
--

DROP TABLE IF EXISTS `seguro_empresa`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro_empresa` (
  `seguro_empresa_id` int(11) NOT NULL AUTO_INCREMENT,
  `empresa_id` int(11) NOT NULL,
  `seguro_id` int(11) NOT NULL,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_empresa_id`),
  KEY `empresa_id` (`empresa_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `seguro_empresa_ibfk_1` FOREIGN KEY (`empresa_id`) REFERENCES `empresa` (`empresa_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `seguro_empresa_ibfk_2` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro_empresa`
--

LOCK TABLES `seguro_empresa` WRITE;
/*!40000 ALTER TABLE `seguro_empresa` DISABLE KEYS */;
INSERT INTO `seguro_empresa` VALUES (1,2,1,'1'),(2,3,1,'1'),(3,3,5,'1'),(4,4,1,'1'),(5,4,4,'1'),(6,5,2,'1'),(7,6,1,'1'),(8,6,4,'1');
/*!40000 ALTER TABLE `seguro_empresa` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `seguro_examen`
--

DROP TABLE IF EXISTS `seguro_examen`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `seguro_examen` (
  `seguro_examen_id` int(11) NOT NULL AUTO_INCREMENT,
  `seguro_id` int(11) NOT NULL,
  `examenes` text NOT NULL,
  `costos` text NOT NULL,
  `estatus_seg` enum('1','2') NOT NULL DEFAULT '1',
  PRIMARY KEY (`seguro_examen_id`),
  KEY `seguro_id` (`seguro_id`),
  CONSTRAINT `seguro_examen_ibfk_1` FOREIGN KEY (`seguro_id`) REFERENCES `seguro` (`seguro_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `seguro_examen`
--

LOCK TABLES `seguro_examen` WRITE;
/*!40000 ALTER TABLE `seguro_examen` DISABLE KEYS */;
INSERT INTO `seguro_examen` VALUES (1,1,'12,15,19,26,21','15,15,15,10,10','1'),(2,2,'15,17,20,27,28,25','17,13,5,10,10,12','1'),(3,3,'14,18,19,15,22,26,25','15,15,15,14,12,12,12','1'),(4,4,'16,14,13,26,25','15,15,15,10,12','1'),(5,5,'15,13,27,19,25','12,12,15,15,17','1'),(6,6,'16,27,28,25','15,16,16,15','1');
/*!40000 ALTER TABLE `seguro_examen` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tipo_antecedente`
--

DROP TABLE IF EXISTS `tipo_antecedente`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tipo_antecedente` (
  `tipo_antecedente_id` int(11) NOT NULL,
  `nombre` varchar(50) NOT NULL,
  `fecha_creacion` datetime NOT NULL,
  `estatus_tip` enum('1','2') NOT NULL,
  PRIMARY KEY (`tipo_antecedente_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tipo_antecedente`
--

LOCK TABLES `tipo_antecedente` WRITE;
/*!40000 ALTER TABLE `tipo_antecedente` DISABLE KEYS */;
INSERT INTO `tipo_antecedente` VALUES (1,'Antecedentes Patológicos','2023-05-28 23:51:47','1'),(2,'Antecedentes Psicológicos','2023-05-28 23:51:47','1'),(3,'Antecedentes médicos familiares','2023-05-28 23:51:47','1'),(4,'Cirugías o traumatismos','2023-05-28 23:51:47','1'),(5,'Alergias','2023-05-28 23:51:47','1'),(6,'Reacción a medicamentos','2023-05-28 23:51:47','1'),(7,'Enfermedades Padecidas','2023-05-28 23:51:47','1'),(8,'Tratamientos','2023-05-28 23:51:47','1'),(9,'Hábitos de salud','2023-05-28 00:00:00','1');
/*!40000 ALTER TABLE `tipo_antecedente` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `titular_beneficiado`
--

DROP TABLE IF EXISTS `titular_beneficiado`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `titular_beneficiado` (
  `titular_beneficiado_id` int(11) NOT NULL AUTO_INCREMENT,
  `paciente_beneficiado_id` int(11) NOT NULL,
  `paciente_id` int(11) NOT NULL,
  `estatus_tit` enum('1','2') NOT NULL DEFAULT '1',
  `tipo_relacion` enum('1','2') NOT NULL,
  `tipo_familiar` enum('1','2','3','4',' 5','6') NOT NULL,
  PRIMARY KEY (`titular_beneficiado_id`),
  KEY `paciente_beneficiado_id` (`paciente_beneficiado_id`),
  KEY `paciente_id` (`paciente_id`),
  CONSTRAINT `titular_beneficiado_ibfk_1` FOREIGN KEY (`paciente_beneficiado_id`) REFERENCES `paciente_beneficiado` (`paciente_beneficiado_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `titular_beneficiado_ibfk_2` FOREIGN KEY (`paciente_id`) REFERENCES `paciente` (`paciente_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `titular_beneficiado`
--

LOCK TABLES `titular_beneficiado` WRITE;
/*!40000 ALTER TABLE `titular_beneficiado` DISABLE KEYS */;
INSERT INTO `titular_beneficiado` VALUES (24,12,102,'1','1','4'),(25,13,105,'2','1','1'),(26,14,102,'2','1','6'),(27,14,105,'2','1','6'),(28,15,112,'1','2','2'),(29,16,114,'1','2','1'),(30,17,114,'1','2','1'),(31,13,112,'1','2','1');
/*!40000 ALTER TABLE `titular_beneficiado` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usuario`
--

DROP TABLE IF EXISTS `usuario`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `usuario` (
  `usuario_id` int(11) NOT NULL AUTO_INCREMENT,
  `nombres` varchar(40) NOT NULL,
  `apellidos` varchar(40) NOT NULL,
  `nombre` varchar(16) NOT NULL,
  `clave` varchar(100) NOT NULL,
  `tokken` varchar(10) DEFAULT NULL,
  `intentos` varchar(10) DEFAULT NULL,
  `rol` int(11) NOT NULL,
  `pin` varchar(100) NOT NULL,
  `estatus_usu` enum('1','2') NOT NULL DEFAULT '2',
  `fecha_creacion` datetime NOT NULL,
  PRIMARY KEY (`usuario_id`)
) ENGINE=InnoDB AUTO_INCREMENT=34 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usuario`
--

LOCK TABLES `usuario` WRITE;
/*!40000 ALTER TABLE `usuario` DISABLE KEYS */;
INSERT INTO `usuario` VALUES (27,'Oriana Carolina','Blanco','Oriana','$2y$10$npllQrVRnuLbFIHvxiOa2uP13oqQG6ZZdUWS9y6OPNozTNg5rA582','05f79daaa2',NULL,2,'$2y$10$k0KKtlyCGVNXwNpG.kkZPemjBb/6ydpsAyEGaWeWoOtShJTKSHUEK','1','2024-06-16 11:23:53'),(28,'Enrique Miguel','Chacón Almérida','Enrique','$2y$10$3vXSdQ0rvbWiS/Gld0EDE.VWDKvhFe8IiBtl6feHLESxacUL51lWm','fab7789d96',NULL,3,'$2y$10$.WbJBGNLaebuQ0Y2o/Rk3.MipHi8kN9Uz/Kq6ii4yo5.lfQ2WwwP','1','2024-06-16 11:24:54'),(29,'Francis Mayini','Baloa Coronado','Francis','$2y$10$D9RZvFwP7i1rpFrkxlXK7.11WtMSvzD.XDMPkxXSkivtG.XDUkXCy','d1805ca4da',NULL,4,'$2y$10$Sk/go279YbV8HQYdSKB8B.yGyBcM5O/AEZMMQBJxWz2ojFxPYGnt6','1','2024-06-16 11:26:00'),(30,'Angelica María','Alvarado Perez','Angelica','$2y$10$iwx0G2pGNrTnp9nzv6SYHOiSjU6507xsxs.PDU98cWvj4r1Edv04S',NULL,NULL,4,'$2y$10$BJO533SO38hewjL2tX5KbOAquKXB4rFAzmYYN65x6bFektWcYCb9G','1','2024-06-16 11:26:48'),(31,'Gloria Carmen','Sanchez García','Rosa','$2y$10$s6yFgc61RaKAewpX5mVnqOujVY2XIJ1bGV7qzCY0z175mlK6xmITy','f5b044f625',NULL,5,'$2y$10$2epn.lpBXcuk20rupAUa2.4syXT3aG.UJkfbw0kjuDkYVyZ8cdZGq','1','2024-06-16 11:27:48'),(32,'Aura','Mendoza','Aura','$2y$10$PQVk/xOw.wg/YXfqy9FHXePQ7AHbRR55iUEHEd6cZYWN7jmtdONkS','a080085007',NULL,1,'$2y$10$KheCMhFLn6UozTFc3KpOU.RLNHiygoSeB09mK8rZBaeejJZD4fN4a','1','2024-06-16 11:36:25');
/*!40000 ALTER TABLE `usuario` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-07-10 17:06:29
